﻿using DomainLayer.Models;
using DomainLayer.Enums;
using System.Collections.Generic;
using System.Linq;

namespace RepositoryLayer
{
    public class UserRepo
    {

        public List<UserModel> GetUserDetails(UserRoleChoiceEnum role)
        {
            switch(role)
            {
                case UserRoleChoiceEnum.Student: return DataSource._userList.Where(m => m.IsStudent).ToList();                   
                case UserRoleChoiceEnum.Other: return DataSource._userList.Where(m => !m.IsStudent).ToList();
                default: return DataSource._userList.ToList();
            }
            
        }
        public void SetUserDetails(RegistrationModel robj)
        {
            DataSource._userList.Add(new UserModel(robj.FirstName, robj.LastName, robj.Email, robj.Password, robj.IsStudent));
        }
    }
}
