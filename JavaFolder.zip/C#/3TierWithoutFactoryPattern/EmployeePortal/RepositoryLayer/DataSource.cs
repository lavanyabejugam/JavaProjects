﻿using DomainLayer.Models;
using System.Collections.Generic;

namespace RepositoryLayer
{
    internal class DataSource
    {
        internal static List<UserModel> _userList = new List<UserModel>();
    }
}
