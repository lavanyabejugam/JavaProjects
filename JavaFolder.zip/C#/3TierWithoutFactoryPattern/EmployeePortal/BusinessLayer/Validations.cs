﻿using RepositoryLayer;
namespace BusinessLayer
{
    public static class Validations
    {
        /// <summary>
        /// validating EmailID
        /// </summary>
        /// <param name="email">EmailId entered during registration</param>
        /// <returns>True-if EmailId is valid or Flase-if EmailId is not valid</returns>
        public static bool ValidateEmail(string email)
        {
            AuthencationRepo _authRepo = new AuthencationRepo();
            bool Flag = false;
            if (email.Contains("@") && email.Contains(".com") && _authRepo.ValidateEmail(email))
            {
                Flag = true;
            }
            return Flag;
        }
        /// <summary>
        /// validating Password 
        /// </summary>
        /// <param name="password">Password entered during registration</param>
        /// <returns>True-if Password is valid or Flase-if Password is not valid</returns>
        public static bool ValidatePassword(string password)
        {
            int validConditions = 0;
            if (password.Length < 9)
            {
                return false;
            }
            foreach (char c in password)
            {
                if (c >= 'a' && c <= 'z')
                {
                    validConditions++;
                    break;
                }
            }
            foreach (char c in password)
            {
                if (c >= 'A' && c <= 'Z')
                {
                    validConditions++;
                    break;
                }
            }
            foreach (char c in password)
            {
                if (c >= '0' && c <= '9')
                {
                    validConditions++;
                    break;
                }
            }
            if (validConditions == 3)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// validating FirstName
        /// </summary>
        /// <param name="firstName">FirstName entered during registration</param>
        /// <returns>True-if FirstName is valid or Flase-if FirstName is not valid</returns>
        public static bool ValidateFirstName(string firstName)
        {
            if (firstName.Length > 0)
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// validating LastName
        /// </summary>
        /// <param name="lastName">LastName entered during registration</param>
        /// <returns>True-if LastName is valid or Flase-if LastName is not valid</returns>

        public static bool ValidateLastName(string lastName)
        {
            if (lastName.Length > 0)
            {
                return true;
            }
            return false;
        }
    }
}


