﻿using DomainLayer.Enums;
using DomainLayer.Models;
using System.Collections.Generic;
using RepositoryLayer;

namespace BusinessLayer
{
    public class UserBusiness
    {
        UserRepo _userRepo;

        public UserBusiness()
        {
            _userRepo = new UserRepo();
        }
        /// <summary>
        /// passing entered information during registration to data access layer
        /// </summary>
        /// <param name="robj"> object of RegistrationModel</param>
        public void SetUserDetails(RegistrationModel robj)
        {
            _userRepo.SetUserDetails(robj);
        }
        /// <summary>
        /// Gets required information from DataAccessLayer and return to Presentation layer
        /// </summary>
        /// <param name="role">It's an user choice</param>
        /// <returns></returns>
        public List<UserModel> GetUserDetails(UserRoleChoiceEnum role)
        {
            return _userRepo.GetUserDetails(role);
        }
    }
}
