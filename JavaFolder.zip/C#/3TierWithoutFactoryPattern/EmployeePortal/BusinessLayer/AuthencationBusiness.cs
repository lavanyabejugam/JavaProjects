﻿using RepositoryLayer;
using DomainLayer.Models;

namespace BusinessLayer
{
    public class AuthencationBusiness
    {
        AuthencationRepo _authRepo;

        public AuthencationBusiness()
        {
            _authRepo = new AuthencationRepo();
        }
        /// <summary>
        /// Validating login
        /// </summary>
        /// <param name="loginModel">object of LoginModel</param>
        /// <returns></returns>
        public bool ValidateLogin(LoginModel loginModel)
        {
            return _authRepo.ValidateLogin(loginModel);
        }
  
    }
}