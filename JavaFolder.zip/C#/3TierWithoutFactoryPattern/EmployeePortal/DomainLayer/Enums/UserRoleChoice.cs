﻿namespace DomainLayer.Enums
{
    public enum UserRoleChoiceEnum
    {
        Student = 1,
        Other = 2
    }
    
}