﻿namespace DomainLayer
{
    public static class StringLiterals
    {
        public static string _invalidEmail = "Invalid Email";
    }
}