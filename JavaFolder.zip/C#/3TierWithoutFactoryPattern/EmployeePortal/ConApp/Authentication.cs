﻿using DomainLayer.Models;
using System;
using BusinessLayer;
using DomainLayer.Enums;

namespace ConApp
{
    class Authentication
    {
        AuthencationBusiness _authBusiness;
        LoginModel _lmobj;
        RegistrationModel _rmobj;
        UserBusiness _ubobj;
        UserModule _userModule;
        public Authentication()
        {
            _authBusiness = new AuthencationBusiness();
            _lmobj = new LoginModel();
            _rmobj = new RegistrationModel();
            _ubobj = new UserBusiness();
            _userModule = new UserModule();
        }
        /// <summary>
        ///Method to login
        /// </summary>
        internal void Login()
        {
            Console.Write("EmailId : ");
            _lmobj.Email = Console.ReadLine();
            Console.Write("Password : ");
            _lmobj.Password = Console.ReadLine();
            if (_authBusiness.ValidateLogin(_lmobj))
            {
                Console.WriteLine("Enter 1 to see students information");
                Console.WriteLine("Enter 2 to see other than student information");
                UserRoleChoiceEnum role;
                role = (UserRoleChoiceEnum)Convert.ToInt32(Console.ReadLine());
                var Info = _userModule.GetUserDetails(role);
                for (int idx = 0; idx < Info.Count; idx++)
                {
                    Console.WriteLine("FirstName :" + Info[idx].FirstName);
                    Console.WriteLine("LastName :" + Info[idx].LastName);
                    Console.WriteLine("Email :" + Info[idx].Email);
                    Console.WriteLine("IsStudent :" + Info[idx].IsStudent);
                }
            }
            else
            {
                Console.WriteLine("Password does not match ");
                Login();
            }

        }
        /// <summary>
        /// Method to register
        /// </summary>
        internal void Register()
        {
            Console.Write("FirstName: ");
            _rmobj.FirstName = Console.ReadLine();
            if (!Validations.ValidateFirstName(_rmobj.FirstName))
            {
                Register();
            }
            Console.Write("LastName: ");
            _rmobj.LastName = Console.ReadLine();
            if (!Validations.ValidateLastName(_rmobj.LastName))
            {
                Register();
            }
            Console.Write("EmailId: ");
            _rmobj.Email = Console.ReadLine();
            if (!Validations.ValidateEmail(_rmobj.Email))
            {
                Register();
            }
            Console.WriteLine("Your Password must contain atleast one captial letter, atleastone small letter and atleast one number");
            Console.Write("Password: ");
            _rmobj.Password = Console.ReadLine();

            if (!Validations.ValidatePassword(_rmobj.Password))
            {
                Register();
            }
            Console.WriteLine("Type of registration");
            Console.WriteLine("Enter 1 to regsiter as a student");
            Console.WriteLine("Enter 2 to register as other");
            int typeOfReg = Convert.ToInt32(Console.ReadLine());
            if (typeOfReg == 1)
            {
                _rmobj.IsStudent = true;
            }
            else
            {
                _rmobj.IsStudent = false;
            }
            _ubobj.SetUserDetails(_rmobj);
        }
    }
}
