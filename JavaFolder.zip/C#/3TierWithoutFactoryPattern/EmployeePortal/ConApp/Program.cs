﻿using DomainLayer.Enums;
using System;

namespace ConApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Authentication authConApp = new Authentication();
            UserChoice choice = 0;
            while (choice != UserChoice.Exit)
            {
                Console.WriteLine("User Choice :");
                Console.WriteLine("1 : Login");
                Console.WriteLine("2 : Registration");
                Console.WriteLine("3 : Exit");
                choice = (UserChoice)Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case UserChoice.Login:
                        authConApp.Login();
                        break;

                    case UserChoice.Register:
                        authConApp.Register();
                        break;
                }
            }
        
        }
    }
}
