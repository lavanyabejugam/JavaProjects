﻿
namespace ConApp.Enums
{
    internal enum UserChoice
    {
        Login = 1,
        Register = 2,
        Exit = 3
    }
}
