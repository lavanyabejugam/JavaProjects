﻿using System.Collections.Generic;
using BusinessLayer;
using DomainLayer.Enums;
using DomainLayer.Models;

namespace ConApp
{
    class UserModule
    {
        internal List<UserModel> GetUserDetails(UserRoleChoiceEnum role)
        {
            UserBusiness ubobj = new UserBusiness();
            return ubobj.GetUserDetails(role);
        }
    }
}
