using System;

namespace Add2BinaryFloats
{
    public class AddTwoBinary
    {
        Compliment _compliment;
        public AddTwoBinary()
        {
            _compliment = new Compliment();
        }
        /// <summary>
        /// Adding two binary strings
        /// </summary>
        /// <param name="FirstNum">This is the first number taken from user</param>
        /// <param name="SecondNum">This is the second number taken from user</param>
        /// <returns></returns>
        public string AddBinary(float firstNum, float secondNum) 
        {
            Convertion convertion = new Convertion();
            string BinaryFirstNum, BinarySecondNum; 
            BinaryFirstNum = convertion.FloatToBinary(Math.Abs(firstNum), 8);
            BinarySecondNum = convertion.FloatToBinary(Math.Abs(secondNum), 8);
            
            var binaryStrings = EqualLengths(BinaryFirstNum, BinarySecondNum);
            BinaryFirstNum = binaryStrings.Item1;
            BinarySecondNum = binaryStrings.Item2;

            if(firstNum < 0)
            {
                BinaryFirstNum = _compliment.Perform2sCompliment(BinaryFirstNum);
            }
            if(secondNum < 0)
            {
                BinarySecondNum = _compliment.Perform2sCompliment(BinarySecondNum);
            }

            string Result = String.Empty;
            int MaxLength = (BinaryFirstNum.Length > BinarySecondNum.Length) ? (BinaryFirstNum.Length) : (BinarySecondNum.Length);
            int Carry = 0, Sum;
            
            /* Adding two binary strings*/
            for(int idx = (MaxLength - 1); idx >= 0 ; idx--)
            {
                if(BinaryFirstNum[idx] == '.')
                {
                    Result = '.' + Result;
                    continue;
                }
                Sum = ((BinaryFirstNum[idx] + BinarySecondNum[idx] + Carry) - 96) % 2;
                Carry = ((BinaryFirstNum[idx] + BinarySecondNum[idx] + Carry) - 96) / 2;
                Result = Sum + Result;
            }
            Result = FinalResult(Result, Carry, firstNum, secondNum);
            return Result;
        }
        /// <summary>
        /// Checking whether user inputs are positive or negative and modifing the Result
        /// </summary>
        /// <param name="result"> optained by adding binary formats of user inputs </param>
        /// <param name="Carry"> optained by adding binary formats of user inputs </param>
        /// <param name="FirstNum"> This is the first number taken from user </param>
        /// <param name="SecondNum"> This is the second number taken from user</param>
        /// <returns></returns>
        public string FinalResult(string result, int Carry, float firstNum, float secondNum)
        {
            
            /* If both the Inputs are positive */ 
            if((Carry == 1) && (firstNum > 0) && (secondNum > 0))
            {
                result = Carry + result;
            }
            
            /* If both the Inputs are negative with carry = 0*/    
            else if((Carry == 0) && (firstNum < 0) && (secondNum < 0))
            {
                result = _compliment.Perform2sCompliment(result);
                result = "1" + result;                
            }
            /* If both the Inputs are negative with carry = 1 */
            else if((Carry == 1) && (firstNum < 0) && (secondNum < 0))
            {
                result = _compliment.Perform2sCompliment(result);
            }
            
            else if(((firstNum < 0) && (Math.Abs(firstNum) > secondNum))
                     || ((secondNum < 0) && (Math.Abs(secondNum) > firstNum)))
            {
                result = _compliment.Perform2sCompliment(result);
            }
            
            return result; 
        }
        
        
        /// <summary>
        /// Making lengths of two binary strings equal 
        /// </summary>
        /// <param name="BinaryFirstNum"> Binary format of first user input </param>
        /// <param name="BinarySecondNum"> Binary format of second user input </param>
        /// <returns> Two strings after making there lengths equal </returns>
        public Tuple<string, string> EqualLengths(string BinaryFirstNum, string BinarySecondNum)
        {
            int l1 = BinaryFirstNum.Length;
            int l2 = BinarySecondNum.Length;
            if(l1 > l2)
            {
                for(int idx = 0; idx < (l1 - l2); idx++)
                {
                    BinarySecondNum = '0' + BinarySecondNum;
                }
            }
            else if(l1 < l2)
            {
                for(int idx = 0; idx < (l2 - l1); idx++)
                {
                    BinaryFirstNum = '0' + BinaryFirstNum;
                }
            }
            return Tuple.Create(BinaryFirstNum, BinarySecondNum);
        }
    }
}