﻿using System;
namespace Add2BinaryFloats
{
    public class Program
    {
        public static void Main()
        {
            /* Create an object for the class */
            AddTwoBinary obj = new AddTwoBinary();
            Convertion convertion = new Convertion();
            /* Take two Floating Inputs */
            float firstNum, secondNum;
            Console.WriteLine(StringLiterals._firstValue);
            firstNum = (float)Convert.ToDouble(Console.ReadLine());
            Console.WriteLine(StringLiterals._secondValue);
            secondNum = (float)Convert.ToDouble(Console.ReadLine());
            /* Add two binary strings */
            string sum = obj.AddBinary(firstNum, secondNum);
            Console.WriteLine(StringLiterals._result+ sum);
            /* convert result to float */
            string result = convertion.BinaryToFloat(firstNum, secondNum, sum);
            Console.WriteLine(result);
            Console.ReadLine();
        }
    }
}