﻿using System;

namespace Add2BinaryFloats
{
    class Convertion
    {
        /// <summary>
        /// Converting user floated inputs into binary
        /// </summary>
        /// <param name="FloatNum"> Absolute form of user flaoted input </param>
        /// <param name="Precision"> Number of digits after decimal point </param>
        /// <returns> binary format of the user floated input in string format</returns>
        public string FloatToBinary(float FloatNum, int Precision)
        {
            int Integer, Remainder;
            string BinaryInteger = string.Empty, BinaryDecimal = string.Empty;
            Integer = (int)FloatNum;
            float Fraction = FloatNum - Integer;
            /* Convert Integeral part of input into binary format */
            while (Integer != 0)
            {
                Remainder = Integer % 2;
                BinaryInteger = Remainder + BinaryInteger;
                Integer = Integer / 2;
            }

            /* Convert decimal part of input into binary format */
            while (Precision != 0)
            {
                BinaryDecimal = BinaryDecimal + (int)(Fraction * 2);
                Fraction = (Fraction * 2) - (int)(Fraction * 2);
                Precision--;
            }
            return BinaryInteger + '.' + BinaryDecimal;
        }

        /// <summary>
        /// Convert binary to floated value
        /// </summary>
        /// <param name="firstNum"> This is the first number taken from user </param>
        /// <param name="secondNum"> This is the second number taken from user </param>
        /// <param name="result"> optained by adding binary formats of user inputs </param>
        /// <returns></returns>
        public string BinaryToFloat(float firstNum, float secondNum, string result)
        {
            string str = string.Empty;
            int dot = result.IndexOf(@".");
            double IntegerPartSum = 0, power = 0;
            for (int i = (dot - 1); i >= 0; i--)
            {
                IntegerPartSum = (Char.GetNumericValue(result[i]) * Math.Pow(2, power)) + IntegerPartSum;
                power++;
            }

            double DecimalPartSum = 0;
            power = -1;
            for (int j = dot + 1; j < result.Length; j++)
            {
                DecimalPartSum = ((Char.GetNumericValue(result[j])) * (Math.Pow(2, power))) + DecimalPartSum;
                power--;
            }
            if (((firstNum < 0) && (Math.Abs(firstNum) > secondNum)) ||
            ((secondNum < 0) && (Math.Abs(secondNum) > firstNum)))
            {
                str = "-" + Convert.ToString(IntegerPartSum + DecimalPartSum);
                return str;
            }
            str = Convert.ToString(IntegerPartSum + DecimalPartSum);
            return str;
        }
    }
}
