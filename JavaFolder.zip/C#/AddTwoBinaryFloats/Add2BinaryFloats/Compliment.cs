﻿namespace Add2BinaryFloats
{
    class Compliment
    {
        /// <summary>
        /// If user inputs are neagtive performing 2's compliment
        /// </summary>
        /// <param name="num"> The number on which 2's compliment is to be performed </param>
        /// <returns> 2's compliment of given number in string format </returns>
        public string Perform2sCompliment(string num)
        {
            char[] arr = num.ToCharArray();
            int idx;
            for (idx = (arr.Length - 1); idx >= 0; idx--)
            {
                if (arr[idx] == '1')
                {
                    break;
                }
            }
            for (int k = (idx - 1); k >= 0; k--)
            {
                if (arr[k] == '1')
                {
                    arr[k] = '0';
                }
                else if (arr[k] == '.')
                {
                    continue;
                }
                else
                {
                    arr[k] = '1';
                }
            }
            string Str = new string(arr);
            return Str;
        }
    }
}
