﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add2BinaryFloats
{
    class StringLiterals
    {
        public static string _firstValue = "Enter the first float value : ";
        public static string _secondValue = "Enter the second float value : ";
        public static string _result = "The result after addition : " ;
    }
}
