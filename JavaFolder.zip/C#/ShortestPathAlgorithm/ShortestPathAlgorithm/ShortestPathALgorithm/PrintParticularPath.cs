﻿using System;

namespace ShortestPathALgorithm
{
    class PrintParticularPath
    {
        void PrintPath(int[] parent, int des)
        {
            if (parent[des] == -1)
            {
                return;
            }
            PrintPath(parent, parent[des]);

            Console.Write(des);
        }

        internal void PrintSolution(int[] dist, int n, int[] parent, int src, int des)
        {
            Console.Write(StringLiterals._output);
            Console.Write("\n{0} -> {1} \t\t {2}\t\t {3}", src, des, dist[des], src);
            PrintPath(parent, des);
        }
    }
}
