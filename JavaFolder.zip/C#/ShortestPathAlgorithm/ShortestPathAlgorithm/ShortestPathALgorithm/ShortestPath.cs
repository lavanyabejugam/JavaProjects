﻿namespace ShortestPathALgorithm
{
    class ShortestPath
    {
        int MinDistance(int[] dist, bool[] sptSet, int length)
        {
            int min = int.MaxValue, min_index = -1;

            for (int idx = 0; idx < length; idx++)
            {
                if (sptSet[idx] == false && dist[idx] <= min)
                {
                    min = dist[idx];
                    min_index = idx;
                }
            }
            return min_index;
        }

        internal void ShorestPathAlgorithm(int[,] graph, int src, int des, int length)
        {
            PrintParticularPath print = new PrintParticularPath();
            int[] dist = new int[length];
            bool[] sptSet = new bool[length];
            int[] parent = new int[length];

            for (int idx = 0; idx < length; idx++)
            {
                parent[idx] = -1;
                dist[idx] = int.MaxValue;
                sptSet[idx] = false;
            }

            dist[src] = 0;

            for (int count = 0; count < (length - 1); count++)
            {
                int minDistance = MinDistance(dist, sptSet, length);
                sptSet[minDistance] = true;
                for (int idx = 0; idx < length; idx++)
                {
                    if (!sptSet[idx] && graph[minDistance, idx] != 0 && dist[minDistance] != int.MaxValue && dist[minDistance] + graph[minDistance, idx] < dist[idx])
                    {
                        parent[idx] = minDistance;
                        dist[idx] = dist[minDistance] + graph[minDistance, idx];
                    }
                }
            }
            print.PrintSolution(dist, length, parent, src, des);
        }
    }
}
