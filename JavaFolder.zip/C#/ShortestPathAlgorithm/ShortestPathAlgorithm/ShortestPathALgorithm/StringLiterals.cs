﻿namespace ShortestPathALgorithm
{
    class StringLiterals
    {
        public static string _source = "Enter the source: ";
        public static string _destination = "Enter the destination: ";
        public static string _output = "Vertex	 Distance " + "from Source  " + "Path from SrcToDes\n";
    }
}
