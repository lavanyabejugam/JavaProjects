﻿namespace OutParameterReflection
{
    public class ThreadsWithOutParameter
    {
        public void OperationsOn2Numbers(int num1, int num2, out int sum, out int product)
        {
            sum = num1 + num2;
            product = num1 * num2;
        }
        public void OperationsOnTwoNumbers(int num1, int num2, out int sum, out int product)
        {
            num1 = 20;
            num2 = 30;
            sum = num1 + num2;
            product = num1 * num2;
        }
    }
}
