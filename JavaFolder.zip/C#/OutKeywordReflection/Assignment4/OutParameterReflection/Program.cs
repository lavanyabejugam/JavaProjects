using System;
using System.Threading;
namespace OutParameterReflection
{
    public class Program
    {
        public static void Main()
        {
            ThreadsWithOutParameter thread = new ThreadsWithOutParameter();
            int num1 = 10;
            int num2 = 20;
            int sum = 0;
            int product = 0;
            Thread myNewThread1 = new Thread(() => thread.OperationsOn2Numbers(num1, num2, out sum, out product));
            Thread myNewThread2 = new Thread(() => thread.OperationsOnTwoNumbers(num1, num2, out sum, out product));

            myNewThread1.Start();
            myNewThread1.Join();
            Console.WriteLine("MainThread1 : Sum : {0}, Product : {1}", sum, product);

            myNewThread2.Start();
            myNewThread2.Join();
            Console.WriteLine("MainThread2 : Sum : {0}, Product : {1}", sum, product);

            Console.ReadLine();
        }
    }
}