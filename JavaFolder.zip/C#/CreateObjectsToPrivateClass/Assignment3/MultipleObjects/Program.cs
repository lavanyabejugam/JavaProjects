using System;
namespace MultipleObjects
{
    public class Program
    {
	    public static void Main()
	    {
		    PrivateClass obj1 = PrivateClass.ReturnObject();
		    PrivateClass obj2 = PrivateClass.ReturnObject();
		    PrivateClass obj3 = PrivateClass.ReturnObject();
		    PrivateClass obj4 = PrivateClass.ReturnObject();
		    PrivateClass obj5 = PrivateClass.ReturnObject();
		    PrivateClass obj6 = PrivateClass.ReturnObject();
		    obj1.Dispose();
            obj2.Dispose();

		    PrivateClass obj7 = PrivateClass.ReturnObject();
		    PrivateClass obj8 = PrivateClass.ReturnObject();
            Console.ReadLine();
	    }
    }
}