﻿using System;
namespace MultipleObjects
{
    public class PrivateClass : IDisposable
    {
        static int NoOfObjectsCreated = 0;
        private bool IsDisposed = false;
        //Call Dispose to free resources explicitly
        public void Dispose()
        {
            Dispose(true);
            NoOfObjectsCreated--;
            GC.SuppressFinalize(this);
        }
            
        //Implementing dispose to free resources
        protected virtual void Dispose(bool disposedStatus)
        {
            if (!IsDisposed)
            {
                IsDisposed = true;
                // Released unmanaged Resources
                if (disposedStatus) 
                {
                    // Released managed Resources
                }
            }
        }
        
        private PrivateClass()
        {

        }
    
        public static PrivateClass ReturnObject()
        {
            if(NoOfObjectsCreated < 5)
            {
                NoOfObjectsCreated++;
                Console.WriteLine("Object{0} Created", NoOfObjectsCreated);
                return new PrivateClass();
            }
            else
            {
                throw(new Exception("Error : More number of objects for a private constructor class"));
            }
        }
    }
}