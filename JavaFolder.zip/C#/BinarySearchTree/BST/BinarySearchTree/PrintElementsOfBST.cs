﻿using System;

namespace BinarySearchTree
{
    class PrintElementsOfBST
    {
        /// <summary>
        /// Method to print elements of BST in decending order 
        /// </summary>
        /// <param name="root">Root node of BST</param>
        public void DecendingOrder(Node root)
        {
            if (root != null)
            {
                DecendingOrder(root._right);
                Console.Write(root._data + " ");
                DecendingOrder(root._left);

            }
        }

        /// <summary>
        /// Method to print numbers elements of BST in ascending order
        /// </summary>
        /// <param name="root">Root node of BST</param>
        public void AscendingOrder(Node root)
        {
            if (root != null)
            {
                AscendingOrder(root._left);
                Console.Write(root._data + " ");
                AscendingOrder(root._right);
            }
        }
    }
}
