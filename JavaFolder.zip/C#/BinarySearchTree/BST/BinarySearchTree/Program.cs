using System;

namespace BinarySearchTree
{
    class Program
    {
        static void Main(string[] args)
        {
            BinarySearchTree tree = new BinarySearchTree();
            PrintElementsOfBST print = new PrintElementsOfBST();
            int size;
            Console.WriteLine("Enter the number of elements in a tree: ");
            size = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the tree elemnets: ");
            int[] arr = new int[size];
            // Taking input and inserting into the BST
            for (int i = 0; i < size; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
                tree.InsertElementsIntoBST(arr[i]);
            }
            // Printing numbers in ascending order 
            Console.WriteLine("Ascending Order: ");
            print.AscendingOrder(tree.ReturnRoot());
            Console.WriteLine(" ");
            //Printing numbers in decending order
            Console.WriteLine("Decending Order: ");
            print.DecendingOrder(tree.ReturnRoot());
            Console.WriteLine(" ");
            // Searching for the target 
            int num;
            Console.WriteLine("Enter the target");
            num = Convert.ToInt32(Console.ReadLine());
            string info = tree.Search(num);
            Console.WriteLine(info);
            Console.ReadLine();
        }
    }
}