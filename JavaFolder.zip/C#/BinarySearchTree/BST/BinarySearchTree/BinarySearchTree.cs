namespace BinarySearchTree
{
    class BinarySearchTree
    {
        public Node root;

        /// <summary>
        /// Constructor to initialize class members
        /// </summary>
        public BinarySearchTree()
        {
            root = null;
        }

        /// <summary>
        /// Mathod to return root node
        /// </summary>
        /// <returns></returns>

        public Node ReturnRoot()
        {
            return root;
        }
        
        /// <summary>
        /// Method to insert numbers into BST
        /// </summary>
        /// <param name="value">Value to be inserted into BST</param>
        public void InsertElementsIntoBST(int value)
        {
            Node newNode = new Node();
            newNode._data = value;
            if (root == null)
                root = newNode;
            else
            {
                Node current = root;
                while (true)
                {
                    if (value < current._data)
                    {
                        if (current._left == null)
                        {
                            current._left = newNode;
                            return;
                        }
                        else
                        {
                            current = current._left;
                        }
                    }
                    else
                    {
                        if (current._right == null)
                        {
                            current._right = newNode;
                            return;
                        }
                        else
                        {
                            current = current._right;
                        }
                    }
                }
            }
        }
        
        /// <summary>
        /// Method to search for the target
        /// </summary>
        /// <param name="target">User target</param>
        /// <returns></returns>
        public string Search(int target)
        {
            Node current = root;
            while (true)
            {
                if ((root == null) || (current == null))
                {                  
                    return StringLiterals._targetNotFound;
                }
                else
                {
                    if (current._data == target)
                    {                       
                        return StringLiterals._targetFound;
                    }
                    else if (target < current._data)
                    {
                        current = current._left;
                    }
                    else if (target > current._data)
                    {
                        current = current._right;
                    }
                }
            }
        }
    }
}