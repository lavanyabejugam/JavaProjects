﻿namespace BinarySearchTree
{
    class Node
    {
        public int _data;
        public Node _left;
        public Node _right;
    }    
}

