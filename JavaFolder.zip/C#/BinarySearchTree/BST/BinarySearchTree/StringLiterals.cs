﻿namespace BinarySearchTree
{
    class StringLiterals
    {
        public static string _targetNotFound = "Target Not Found";
        public static string _targetFound = "Target Found";
    }
}
