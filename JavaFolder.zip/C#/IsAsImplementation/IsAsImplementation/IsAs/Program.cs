﻿using System;
namespace IsAs
{
    public class Program
    {
        public static void Main()
        {
            IsAsImplementation obj = new IsAsImplementation();
            int integer = 10;
            Console.WriteLine("integer is object :{0}", obj.Is<object>(integer));
            Console.WriteLine("integer as object :{0}", obj.As<object>(integer)); 
            Console.ReadLine();
        }
    }
}

