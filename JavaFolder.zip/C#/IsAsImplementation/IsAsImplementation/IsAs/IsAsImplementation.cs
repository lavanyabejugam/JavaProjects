using System;
namespace IsAs
{
    public class IsAsImplementation
    {
        
        public compatibleType As<compatibleType>(object integer)
        {
            if (Is<compatibleType>(integer))
            {
                return (compatibleType)integer;
            }
            return default(compatibleType);
        }

        public bool Is<compatibleType>(object integer)
        {
            Type typeOfinteger = integer.GetType();
            while (typeOfinteger != null)
            {
                if (typeOfinteger == typeof(compatibleType))
                {
                    return true;
                }
                else
                {
                    typeOfinteger = typeOfinteger.BaseType;
                }
            }
            return false;
        }
    }
}