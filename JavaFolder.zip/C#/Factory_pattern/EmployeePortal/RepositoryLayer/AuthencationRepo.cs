﻿using DomainLayer.Models;
using System.Linq;

namespace RepositoryLayer
{
    internal class AuthencationRepo : IAuthenticateRepo
    {
        /// <summary>
        /// inorder to verify whether emailid and password exists in database
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public bool ValidateLogin(LoginModel loginModel)
        {
            return DataSource._userList.Any(m => m.Email == loginModel.Email &&
             m.Password == loginModel.Password);
        }

        /// <summary>
        /// inorder to check entered emailid should not exist in database
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public bool ValidateEmail(string email)
        {
            if(!DataSource._userList.Any(m => m.Email == email))
            {
                return true;
            }

            return false;
        }
    }
}
