﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryLayer
{
   public class FactoryRepo
    {
        public static IAuthenticateRepo AuthRepo()
        {
            return new AuthencationRepo();
        }
        public static IUserRepo UserDetails()
        {
            return new UserRepo();
        }
    }
}
