﻿using DomainLayer.Models;
using DomainLayer.Enum;
using System.Collections.Generic;
using System.Linq;

namespace RepositoryLayer
{
    internal class UserRepo : IUserRepo
    {

        public List<UserModel> GetUserDetails(UserRoleChoice role)
        {
            if (role == UserRoleChoice.Student)
            {
                return DataSource._userList.Where(m => m.IsStudent).ToList();
            }
            else if (role == UserRoleChoice.Other)
            {
                return DataSource._userList.Where(m => !m.IsStudent).ToList();
            }
            else
            {
                return DataSource._userList.ToList();
            }
        }
        public void SetUserDetails(RegistrationModel rmObj)
        {
            DataSource._userList.Add(new UserModel(rmObj.FirstName, rmObj.LastName, rmObj.Email, rmObj.Password, rmObj.IsStudent));
        }
    }
}
