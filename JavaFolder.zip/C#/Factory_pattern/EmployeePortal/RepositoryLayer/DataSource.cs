﻿using DomainLayer.Models;
using System.Collections.Generic;

namespace RepositoryLayer
{
    public class DataSource
    {
        public static List<UserModel> _userList = new List<UserModel>();       

    }
}
