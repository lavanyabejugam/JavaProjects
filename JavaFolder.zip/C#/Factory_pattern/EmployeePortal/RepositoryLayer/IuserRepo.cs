﻿using System;
using System.Collections.Generic;
using DomainLayer.Enum;
using DomainLayer.Models;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryLayer
{
    public interface IUserRepo
    {

        List<UserModel> GetUserDetails(UserRoleChoice role);
        void SetUserDetails(RegistrationModel rmObj);
    }
}
