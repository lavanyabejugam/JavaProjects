﻿using DomainLayer.Models;

namespace RepositoryLayer
{
    public interface IAuthenticateRepo
    {
        bool ValidateLogin(LoginModel loginModel);
        bool ValidateEmail(string email);
    }
}
