﻿using DomainLayer.Models;
using System.Collections.Generic;
using RepositoryLayer;
using DomainLayer.Enum;

namespace BusinessLayer
{
    internal class UserBusiness : IUserBusiness
    {

        IUserRepo _userObj;
        public UserBusiness()
        {
            _userObj = FactoryRepo.UserDetails();
        }
        public void SetUserDetails(RegistrationModel robj)
        {

            _userObj.SetUserDetails(robj);
        }

        public List<UserModel> GetUserDetails(UserRoleChoice role)
        {

            return _userObj.GetUserDetails(role);
        }
    }
}
