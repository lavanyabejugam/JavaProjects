﻿using RepositoryLayer;
using DomainLayer.Models;
namespace BusinessLayer
{
    public static class Validations
    {
        /// <summary>
        /// Inorder to verify entered email is correct or not
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>

        public static bool Validate(RegistrationModel registerModel)
        {
            if(ValidateEmail(registerModel.Email) && ValidatePassword(registerModel.Password) && ValidateFirstName(registerModel.FirstName) && ValidateLastName(registerModel.LastName))
            {
                return true;
            }
            return false;
        }
        public static bool ValidateEmail(string email)
        {
            IAuthenticateRepo _authObj;
            _authObj = FactoryRepo.AuthRepo();
            bool Flag = false;
            if(email.Contains("@") && email.Contains(".com") && _authObj.ValidateEmail(email))
            {
                Flag = true;
            }
            return Flag;
        }
        /// <summary>
        /// password should contain one uppercase ,lowercase,digit and length should be greater than 5
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>


        public static bool ValidatePassword(string password)
        {
            int validConditions = 0;
            if(password.Length < 5)
            {
                return false;
            }
            foreach(char c in password)
            {
                if(c >= 'a' && c <= 'z')
                {
                    validConditions++;
                    break;
                }
            }
            foreach(char c in password)
            {
                if(c >= 'A' && c <= 'Z')
                {
                    validConditions++;
                    break;
                }
            }
            foreach(char c in password)
            {
                if(c >= '0' && c <= '9')
                {
                    validConditions++;
                    break;
                }
            }
            if(validConditions == 3)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// entered name length should be greater than 1
        /// </summary>
        /// <param name="Name"></param>
        /// <returns></returns>
        public static bool ValidateFirstName(string Name)
        {
            if(Name.Length > 0)
            {
                return true;
            }
            return false;
        }
        public static bool ValidateLastName(string Name)
        {
            if(Name.Length > 0)
            {
                return true;
            }
            return false;
        }

    }
}


