﻿using RepositoryLayer;
using DomainLayer.Models;


namespace BusinessLayer
{
    internal class AuthencationBusiness : IAuthenticationBusiness
    {


        IAuthenticateRepo _authObj;
        
        
        /// <summary>
        /// To verify Login details emailId and Password
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>

        public bool ValidateLogin(LoginModel loginModel)
        {
            _authObj = FactoryRepo.AuthRepo();
            return _authObj.ValidateLogin(loginModel);
        }


    }
}