﻿using DomainLayer.Models;

namespace BusinessLayer
{
    public interface IAuthenticationBusiness
    {
        bool ValidateLogin(LoginModel loginModel);

    }
}
