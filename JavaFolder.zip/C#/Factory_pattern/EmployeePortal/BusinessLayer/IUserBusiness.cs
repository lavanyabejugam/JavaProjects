﻿using System.Collections.Generic;
using DomainLayer.Enum;
using DomainLayer.Models;
namespace BusinessLayer
{
    public interface IUserBusiness
    {
        void SetUserDetails(RegistrationModel robj);
        List<UserModel> GetUserDetails(UserRoleChoice role);
    }

}
