﻿namespace BusinessLayer
{
    public class FactoryBusiness
    {
        public  IAuthenticationBusiness Authenticate()
        {
            return new AuthencationBusiness();
        }
        public IUserBusiness User()
        {
            return new UserBusiness();
        }
    }
}
