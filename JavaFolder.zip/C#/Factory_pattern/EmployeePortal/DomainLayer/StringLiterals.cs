﻿namespace DomainLayer
{
    public static class StringLiterals
    {
        public static string _validPassword = "Your Password must contain atleast one captial letter, atleastone small letter and atleast one number";
        public static string _validLoginPassword = "Password does not match ";
        public static string _invalidEmail = "Invalid Email";
        public static string _userChoice = "User Choice :";
        public static string _email = "Enter EmailID :";
        public static string _login = "1 : Login";
        public static string _register = "2 : Registration";
        public static string _exit = "3 : Exit";
        public static string _password = "Password : ";
        public static string _userChoice1 = "Enter 1 to see students information";
        public static string _userChoice2 = "Enter 2 to see other than student information";
        public static string _firstName = "FirstName: ";
        public static string _lastName = "LastName: ";
        public static string _typeOfReg = "Type of registration";
        public static string _userRoleChoice1 = "Enter 1 to regsiter as a student";
        public static string _userRoleChoice2 = "Enter 2 to register as other";


    }
}