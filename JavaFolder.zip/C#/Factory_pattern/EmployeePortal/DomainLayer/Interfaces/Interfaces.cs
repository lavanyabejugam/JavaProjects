﻿using System.Collections.Generic;
using DomainLayer.Models;
namespace DomainLayer.Interfaces
{
    public interface IGetDetails
    {
        List<UserModel> GetUserDetails();
    }
}
