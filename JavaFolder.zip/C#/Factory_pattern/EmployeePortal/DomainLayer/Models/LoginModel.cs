﻿namespace DomainLayer.Models
{
    /// <summary>
    // fields to be accepted at the time of login
    /// </summary>
    public class LoginModel
    {
        public string Email { get; set; }
        public string Password { get; set; }


    }
}
