﻿namespace DomainLayer.Enum
{
    /// <summary>
    /// for login and signup
    /// </summary>
    public enum LoginPageChoice
    {
        Login = 1,
        Register = 2,
        Exit = 3

    }
}