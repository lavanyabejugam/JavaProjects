﻿namespace DomainLayer.Enum
{
    public enum UserRoleChoice
    {
        Student = 1,
        Other = 2,
        All = 3

    }
}
