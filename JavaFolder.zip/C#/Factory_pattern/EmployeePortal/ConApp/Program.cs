﻿using DomainLayer;
using DomainLayer.Enum;
using System;

namespace ConApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Authentication authConApp = new Authentication();
            LoginPageChoice choice = 0;
            while (choice != LoginPageChoice.Exit)
            {
                Console.WriteLine(StringLiterals._userChoice);
                Console.WriteLine(StringLiterals._login);
                Console.WriteLine(StringLiterals._register);
                Console.WriteLine(StringLiterals._exit);
                choice = (LoginPageChoice)Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case LoginPageChoice.Login:
                        authConApp.Login();
                        break;

                    case LoginPageChoice.Register:
                        authConApp.Register();
                        break;
                }
            }

        }
    }
}
