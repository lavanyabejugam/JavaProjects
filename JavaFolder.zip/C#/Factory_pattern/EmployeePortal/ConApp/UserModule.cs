﻿using System.Collections.Generic;
using BusinessLayer;
using DomainLayer.Enum;
using DomainLayer.Models;

namespace ConApp
{
    class UserModule
    {
        IUserBusiness _userObj;
        FactoryBusiness _factoryBusinessObj;
        public UserModule()
        {
            _factoryBusinessObj = new FactoryBusiness();
        }
        internal List<UserModel> GetUserDetails(UserRoleChoice role)
        {
            _userObj = _factoryBusinessObj.User();
            return _userObj.GetUserDetails(role);
        }
    }
}
