﻿using DomainLayer.Models;
using DomainLayer;
using System;
using BusinessLayer;
using DomainLayer.Enum;
namespace ConApp
{
    class Authentication
    {
        /// <summary>
        /// User authentication in order to login or register
        /// </summary>

        LoginModel _loginmodelObj;
        RegistrationModel _registermodelObj;
        FactoryBusiness _factoryBusinessObj;
        IAuthenticationBusiness _authObj;
        IUserBusiness _userObj;


        UserModule _userModuleObj;
        public Authentication()
        {

            _loginmodelObj = new LoginModel();
            _registermodelObj = new RegistrationModel();
            _factoryBusinessObj = new FactoryBusiness();

            _userModuleObj = new UserModule();
        }
        /// <summary>
        /// Details for Login
        /// </summary>
        internal void Login()
        {

            Console.Write(StringLiterals._email);
            _loginmodelObj.Email = Console.ReadLine();
            Console.Write(StringLiterals._password);
            _loginmodelObj.Password = Console.ReadLine();
            _authObj = _factoryBusinessObj.Authenticate();
            if(_authObj.ValidateLogin(_loginmodelObj))
            {
                Console.WriteLine(StringLiterals._userChoice1);
                Console.WriteLine(StringLiterals._userChoice2);
                UserRoleChoice role;
                role = (UserRoleChoice)Convert.ToInt32(Console.ReadLine());
                var Info = _userModuleObj.GetUserDetails(role);
                string name, email, isStudent;
                for(int idx = 0; idx < Info.Count; idx++)
                {
                    name = string.Format("Name :{0} {1}", Info[idx].FirstName, Info[idx].LastName);
                    Console.WriteLine(name);
                    email = string.Format("Email :" + Info[idx].Email);
                    Console.WriteLine(email);
                    isStudent = string.Format("IsStudent :" + Info[idx].IsStudent);
                    Console.WriteLine(isStudent);
                }
            }
            else
            {
                Console.WriteLine(StringLiterals._validLoginPassword);
                Login();
            }

        }



        /// <summary>
        /// Details for signup
        /// </summary>
        internal void Register()
        {
            Console.Write(StringLiterals._firstName);
            _registermodelObj.FirstName = Console.ReadLine();

            Console.Write(StringLiterals._lastName);
            _registermodelObj.LastName = Console.ReadLine();

            Console.Write(StringLiterals._email);
            _registermodelObj.Email = Console.ReadLine();

            Console.WriteLine(StringLiterals._validPassword);
            Console.Write(StringLiterals._password);
            _registermodelObj.Password = Console.ReadLine();


            Console.WriteLine(StringLiterals._typeOfReg);
            Console.WriteLine(StringLiterals._userRoleChoice1);
            Console.WriteLine(StringLiterals._userRoleChoice2);
            int typeOfReg = Convert.ToInt32(Console.ReadLine());
            if(typeOfReg == 1)
            {
                _registermodelObj.IsStudent = true;
            }
            else
            {
                _registermodelObj.IsStudent = false;
            }
            if(Validations.Validate(_registermodelObj))
            {
                _userObj = _factoryBusinessObj.User();
                _userObj.SetUserDetails(_registermodelObj);
            }
        }
    }
}

