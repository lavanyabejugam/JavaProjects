package arraylistimplementation;


public class ArrayListImplementation {
    
    public static void main(String[] args) {
        ArrayList<StudentInfo> list = new ArrayList<>();
        list.add(new StudentInfo(1, "Lavanya", "ECE"));
        list.add(new StudentInfo(2, "Roja", "IT"));
        list.add(new StudentInfo(3, "Bejugam", "CSE"));
        System.out.println("List elements : "); 
        list.printArrayListValues(list);
        list.remove(3, list);
        System.out.println("List elements : "); 
        list.printArrayListValues(list);
    }
    
}
