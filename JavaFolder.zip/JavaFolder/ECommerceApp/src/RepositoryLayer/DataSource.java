/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RepositoryLayer;

import DomainLayer.Models.ProductModel;
import DomainLayer.Models.RegistrationModel;

import java.util.*;

/**
 *
 * @author lavanya.bejugam
 */
public class DataSource {
    public static List<RegistrationModel> _userList = new ArrayList<>();
    public static List<ProductModel> _productList = new ArrayList<>();
    public static List<ProductModel> _cartList = new ArrayList<>();
}
