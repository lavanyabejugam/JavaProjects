/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RepositoryLayer;

import DomainLayer.Models.ProductModel;

/**
 *
 * @author lavanya.bejugam
 */
public interface IProductRepo {
    public void SetProductDetails(ProductModel pObj);
    public void DeleteItems(String ItemToBeRemoved);
    public void UpdateItem(String productName, float price);
    public void Display();
    void MoveItemToCart(String productName);
}
