/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RepositoryLayer;

/**
 *
 * @author lavanya.bejugam
 */
public class FactoryRepo {
    public static IAuthenticateRepo AuthRepo()
        {
            return new AuthenticationRepo();
        }
        public static IUserRepo UserDetails()
        {
            return new UserRepo();
        }
        public static IProductRepo product()
        {
            return new ProductRepo();
        }
}
