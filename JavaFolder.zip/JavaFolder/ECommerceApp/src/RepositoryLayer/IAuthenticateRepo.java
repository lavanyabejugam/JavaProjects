/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RepositoryLayer;

import DomainLayer.Models.LoginModel;

/**
 *
 * @author lavanya.bejugam
 */
public interface IAuthenticateRepo {
    boolean ValidateLogin(LoginModel loginModel);
    boolean ValidateEmail(String email);
    boolean IsAdmin(LoginModel loginModel);
}
