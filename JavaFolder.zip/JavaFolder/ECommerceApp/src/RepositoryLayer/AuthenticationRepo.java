/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RepositoryLayer;

import DomainLayer.Models.LoginModel;
import DomainLayer.Models.RegistrationModel;
import DomainLayer.Models.UserModel;

/**
 *
 * @author lavanya.bejugam
 */
class AuthenticationRepo implements IAuthenticateRepo{
    
        /// <summary>
        /// inorder to verify whether emailid and password exists in database
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
    @Override
        public boolean ValidateLogin(LoginModel loginModel)
        {
            
            return DataSource._userList.stream().anyMatch(m -> m.Email.equals(loginModel.getEmail()) && m.Password.equals(loginModel.getPassword()));
        }

        /// <summary>
        /// inorder to check entered emailid should not exist in database
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
    @Override
        public boolean ValidateEmail(String email)
        {
            if(!DataSource._userList.stream().anyMatch(m -> m.Email.equals(email)))
            {
                return true;
            }

            return false;
        }
        @Override
        public boolean IsAdmin(LoginModel loginModel)
        {
            for(RegistrationModel b:DataSource._userList){  
                
                if((b.Email).equals(loginModel.getEmail()))
                {
                    return b.IsAdmin;
                }
            }  
        return false;
    }
}

