/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RepositoryLayer;

import DomainLayer.Models.ProductModel;
import DomainLayer.Models.UserModel;
import RepositoryLayer.DataSource;
import java.util.List;
/**
 *
 * @author lavanya.bejugam
 */
public class ProductRepo implements IProductRepo{        
        @Override
        public void Display(){
            
            for(ProductModel b : DataSource._productList){
                System.out.println("Avaliable Products");
                System.out.println(b.getProductName() + " " + b.getPrice() + " " + b.getDescription() + b.getAvaliableStock());
            }
        }
        @Override
        public void SetProductDetails(ProductModel pObj){            
            DataSource._productList.add(pObj);
            
        }
        @Override
        public void DeleteItems(String ItemToBeRemoved){
            for(ProductModel b:DataSource._productList){  
                if((b.productName).equals(ItemToBeRemoved))
                {
                    DataSource._productList.remove(b);
                }
            }  
       
        }
        @Override
        public void UpdateItem(String productName, float price)
        {
            for(ProductModel b : DataSource._productList){
                if(b.productName.equals(productName)){
                    b.price = price;
                }
            }
        }
        @Override
        public void MoveItemToCart(String productName){
            for(ProductModel b : DataSource._productList){
                if(b.productName.equals(productName)){
                    DataSource._cartList.add(b);
                }
            }
        }
}
