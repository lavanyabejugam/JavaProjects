/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DomainLayer.Enum;

import java.util.*;

/**
 *
 * @author lavanya.bejugam
 */
public enum AdminOptions {
    Add,
   Delete,
    Update,
    Exit;
//    Add(1),
//    Delete(2),
//    Update(3),
//    Exit(4);
//    private int value;
//    private static Map map = new HashMap<>();
//
//    private AdminOptions(int value) {
//        this.value = value;
//    }
//
//    static {
//        for (AdminOptions adminOptions : AdminOptions.values()) {
//            map.put(adminOptions.value, adminOptions);
//        }
//    }
//
//    public static AdminOptions valueOf(int adminOptions) {
//        return (AdminOptions) map.get(adminOptions);
//    }
}
