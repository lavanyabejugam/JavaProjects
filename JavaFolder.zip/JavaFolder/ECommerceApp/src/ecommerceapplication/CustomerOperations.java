/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecommerceapplication;

import BusinessLayer.FactoryBusiness;
import BusinessLayer.IProductBusiness;

/**
 *
 * @author lavanya.bejugam
 */

public class CustomerOperations {
    IProductBusiness _productObj;
    
    FactoryBusiness _factoryBusinessObj;
    public CustomerOperations()
    {
        
        _factoryBusinessObj = new FactoryBusiness();
    
    }
    

    void MoveItemToCart(String productName) {
        _productObj = _factoryBusinessObj.product();
        _productObj.MoveItemToCart(productName);
    }
    
}
