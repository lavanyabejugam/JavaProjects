/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecommerceapplication;

import BusinessLayer.FactoryBusiness;
import BusinessLayer.IUserBusiness;
import DomainLayer.Enum.UserRoleChoice;
import DomainLayer.Models.UserModel;
import java.util.List;

/**
 *
 * @author lavanya.bejugam
 */
public class UserModule {

    IUserBusiness _userObj;
    FactoryBusiness _factoryBusinessObj;

    public UserModule() {
        _factoryBusinessObj = new FactoryBusiness();
    }
     List<UserModel> GetUserDetails(UserRoleChoice role) {
        _userObj = _factoryBusinessObj.User();
        return _userObj.GetUserDetails(role);
    }
}
