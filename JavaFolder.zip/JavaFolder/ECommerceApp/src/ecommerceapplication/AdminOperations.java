/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecommerceapplication;

import BusinessLayer.FactoryBusiness;
import BusinessLayer.IUserBusiness;
import BusinessLayer.IProductBusiness;
import DomainLayer.Models.ProductModel;
import java.util.Scanner;

/**
 *
 * @author lavanya.bejugam
 */
public class AdminOperations {
    
    IProductBusiness _productObj;
    
    FactoryBusiness _factoryBusinessObj;
    public AdminOperations()
    {
        
        _factoryBusinessObj = new FactoryBusiness();
    
    }
    void AddItems()
    {
        ProductModel _productModelObj = new ProductModel();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number of items to be added");
        int items = scanner.nextInt();
                while(items != 0)
                {
                    System.out.println("enter productName");
                _productModelObj.productName = scanner.next();
                System.out.println("enter price");
                _productModelObj.price = Float.parseFloat(scanner.next());
                System.out.println("enter description");
                _productModelObj.description = scanner.next();
                System.out.println("enter avaliableStock");
                _productModelObj.avaliableStock=scanner.nextInt();
                System.out.println("Adding....");
                _productObj = _factoryBusinessObj.product();
                
                _productObj.SetProductDetails(_productModelObj);
                items--;
                }
    }
    void RemoveItems(String ItemToBeRemoved)
    {
        _productObj = _factoryBusinessObj.product();
        _productObj.DeleteItems(ItemToBeRemoved);
    }
    void UpdateItem(String productName, float price)
    {
        _productObj = _factoryBusinessObj.product();
        _productObj.UpdateItem(productName, price);
    }
}
