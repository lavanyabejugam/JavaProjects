/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessLayer;

import DomainLayer.Enum.UserRoleChoice;
import DomainLayer.Models.RegistrationModel;
import DomainLayer.Models.UserModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IUserRepo;
import java.util.List;

/**
 *
 * @author lavanya.bejugam
 */
class UserBusiness implements IUserBusiness{
    
        IUserRepo _userObj;
        public UserBusiness()
        {
            _userObj = FactoryRepo.UserDetails();
        }
        @Override
        public void SetUserDetails(RegistrationModel robj)
        {

            _userObj.SetUserDetails(robj);
        }
        @Override
        public List<UserModel> GetUserDetails(UserRoleChoice role)
        {

            return _userObj.GetUserDetails(role);
        }
    }

