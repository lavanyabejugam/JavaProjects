/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessLayer;

import DomainLayer.Models.LoginModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IAuthenticateRepo;

/**
 *
 * @author lavanya.bejugam
 */
class AuthenticationBusiness implements IAuthenticationBusiness {
    
        IAuthenticateRepo _authObj;
        
        /// <summary>
        /// To verify Login details emailId and Password
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        @Override
        public boolean ValidateLogin(LoginModel loginModel)
        {
            _authObj = FactoryRepo.AuthRepo();
            return _authObj.ValidateLogin(loginModel);
        }
        @Override
        public boolean IsAdmin(LoginModel loginModel)
        {
            _authObj = FactoryRepo.AuthRepo();
            return _authObj.IsAdmin(loginModel);
        }
    }

