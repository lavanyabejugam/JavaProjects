/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessLayer;

import DomainLayer.Models.ProductModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IProductRepo;

/**
 *
 * @author lavanya.bejugam
 */
public class ProductBusiness implements IProductBusiness{
    IProductRepo _productObj;
    
        public ProductBusiness()
        {
            _productObj = FactoryRepo.product();
        }
    @Override
        public void SetProductDetails(ProductModel pobj)
        {          
            _productObj.SetProductDetails(pobj);
        }
        @Override
        public void DeleteItems(String ItemToBeRemoved)
        {

            _productObj.DeleteItems(ItemToBeRemoved);
        }
    @Override
        public void UpdateItem(String productName, float price)
        {
            _productObj.UpdateItem(productName, price);
        }
    @Override
        public void Display()
        {
            _productObj.Display();
        }
        @Override
        public void MoveItemToCart(String productName)
        {
            _productObj.MoveItemToCart(productName);
        }
}
