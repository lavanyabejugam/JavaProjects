/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessLayer;

import DomainLayer.Models.LoginModel;

/**
 *
 * @author lavanya.bejugam
 */
public interface IAuthenticationBusiness {
    boolean ValidateLogin(LoginModel loginModel);
    boolean IsAdmin(LoginModel loginModel);
}
