/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecommerceapplication;

import BusinessLayer.FactoryBusiness;
import BusinessLayer.IAuthenticationBusiness;
import BusinessLayer.IUserBusiness;
import BusinessLayer.Validations;
import DomainLayer.Enum.UserRoleChoice;
import DomainLayer.Models.LoginModel;
import DomainLayer.Models.RegistrationModel;
import DomainLayer.Models.UserModel;
import DomainLayer.StringLiterals;
import java.util.ArrayList;
import java.util.List;

import java.util.Scanner;

/**
 *
 * @author lavanya.bejugam
 */
public class Authentication {
    /// <summary>
    /// User authentication in order to login or register
    /// </summary>

    LoginModel _loginmodelObj;
    RegistrationModel _registermodelObj;
    FactoryBusiness _factoryBusinessObj;
    IAuthenticationBusiness _authObj;
    IUserBusiness _userObj;

    UserModule _userModuleObj;

    public Authentication() {

        _loginmodelObj = new LoginModel();
        _registermodelObj = new RegistrationModel();
        _factoryBusinessObj = new FactoryBusiness();

        _userModuleObj = new UserModule();
    }
        /// <summary>
    /// Details for Login
    /// </summary>
     void Login() {
        
        System.out.print(StringLiterals._email);
        Scanner scanner = new Scanner(System.in);
        _loginmodelObj.Email = scanner.nextLine();
        System.out.print(StringLiterals._password);
        _loginmodelObj.Password = scanner.nextLine();
        _authObj = _factoryBusinessObj.Authenticate();
        if (_authObj.ValidateLogin(_loginmodelObj)) {
            System.out.println(StringLiterals._userChoice1);
            System.out.println(StringLiterals._userChoice2);
            UserRoleChoice role;
            
            role = UserRoleChoice.valueOf(scanner.nextLine());
            List<UserModel> Info = _userModuleObj.GetUserDetails(role);
            //var Info = _userModuleObj.GetUserDetails(role);
//            string name, email, isStudent;
//                for(int idx = 0; idx < Info.size(); idx++)
//                {
//                    System.out.println("Name :{0} {1}", Info[idx].FirstName);
//                    
//                    
//                }
            for(UserModel b:Info){  
    System.out.println(b.FirstName+" "+b.LastName+" "+b.Email+" "+b.IsAdmin);  
    }  
           
        } else {
            System.out.println(StringLiterals._validLoginPassword);
            Login();
        }

    }

        /// <summary>
    /// Details for signup
    /// </summary>
     void Register() {
         Scanner scanner = new Scanner(System.in);
        System.out.print(StringLiterals._firstName);
        _registermodelObj.FirstName = scanner.nextLine();

        System.out.print(StringLiterals._lastName);
        _registermodelObj.LastName = scanner.nextLine();

        System.out.print(StringLiterals._email);
        _registermodelObj.Email = scanner.nextLine();

        System.out.println(StringLiterals._validPassword);
        System.out.print(StringLiterals._password);
        _registermodelObj.Password = scanner.nextLine();

        System.out.println(StringLiterals._typeOfReg);
        System.out.println(StringLiterals._userRoleChoice1);
        System.out.println(StringLiterals._userRoleChoice2);
        int typeOfReg = Integer.parseInt(scanner.nextLine());
        if (typeOfReg == 1) {
            _registermodelObj.IsAdmin = true;
        } else {
            _registermodelObj.IsAdmin = false;
        }
        if (Validations.Validate(_registermodelObj)) {
            _userObj = _factoryBusinessObj.User();
            _userObj.SetUserDetails(_registermodelObj);
        }
    }
}
