package ecommerceapplication;

import DomainLayer.Enum.LoginPageChoice;
import DomainLayer.StringLiterals;
import java.util.Scanner;

public class ECommerceApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Authentication authConApp = new Authentication();
        LoginPageChoice choice;
        do{
        
            System.out.println(StringLiterals._userChoice);
            System.out.println(StringLiterals._login);
            System.out.println(StringLiterals._register);
            System.out.println(StringLiterals._exit);
            choice = LoginPageChoice.valueOf(scanner.nextLine());
            switch (choice) {
                case Login:
                    authConApp.Login();
                    break;

                case Register:
                    authConApp.Register();
                    break;
            }
        }
        while (choice != LoginPageChoice.Exit);
    }

}
