/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DomainLayer;

/**
 *
 * @author lavanya.bejugam
 */
public class StringLiterals {
    public static String _validPassword = "Your Password must contain atleast one captial letter, atleastone small letter and atleast one number";
        public static String _validLoginPassword = "Password does not match ";
        public static String _invalidEmail = "Invalid Email";
        public static String _userChoice = "User Choice :";
        public static String _email = "Enter EmailID :";
        public static String _login = "Login";
        public static String _register = "Registration";
        public static String _exit = "Exit";
        public static String _password = "Password : ";
        public static String _userChoice1 = "Enter Admin to see students information";
        public static String _userChoice2 = "Enter Other to see other than student information";
        public static String _firstName = "FirstName: ";
        public static String _lastName = "LastName: ";
        public static String _typeOfReg = "Type of registration";
        public static String _userRoleChoice1 = "Enter 1 to regsiter as a student";
        public static String _userRoleChoice2 = "Enter 2 to register as other";
}
