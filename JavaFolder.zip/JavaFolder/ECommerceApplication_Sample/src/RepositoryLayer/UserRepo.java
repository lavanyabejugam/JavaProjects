/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package RepositoryLayer;
import DomainLayer.Enum.UserRoleChoice;
import DomainLayer.Models.RegistrationModel;
import DomainLayer.Models.UserModel;
import RepositoryLayer.DataSource;
import RepositoryLayer.IUserRepo;
import java.util.*;
import java.util.stream.Collectors;
/**
 *
 * @author lavanya.bejugam
 */
class UserRepo implements IUserRepo {
    @Override
    public List<UserModel> GetUserDetails(UserRoleChoice role)
        {
            if (role == UserRoleChoice.Admin)
            {                
                return DataSource._userList.stream().filter(p -> p.isIsAdmin()).collect(Collectors.toList());               
            }         
            else
            {
                return DataSource._userList.stream().collect(Collectors.toList());
            }
        }
    @Override
        public void SetUserDetails(RegistrationModel rmObj)
        {
            DataSource._userList.add(new UserModel(rmObj.getFirstName(), rmObj.getLastName(), rmObj.getEmail(), rmObj.getPassword(), rmObj.isIsAdmin()));
        }
}
