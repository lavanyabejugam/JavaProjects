/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RepositoryLayer;

import DomainLayer.Enum.UserRoleChoice;
import DomainLayer.Models.RegistrationModel;
import DomainLayer.Models.UserModel;
import java.util.List;

/**
 *
 * @author lavanya.bejugam
 */
public interface IUserRepo {
    List<UserModel> GetUserDetails(UserRoleChoice role);
        void SetUserDetails(RegistrationModel rmObj);
}
