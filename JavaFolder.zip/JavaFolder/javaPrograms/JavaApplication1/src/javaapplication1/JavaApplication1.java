/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.*;

/**
 *
 * @author lavanya.bejugam
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //HashMap<String, ArrayList<NewClass>> hm1 = new HashMap<>();
        HashMap<String, HashMap<String, ArrayList<NewClass>>> hm = new HashMap<>();
        Scanner scanner = new Scanner(System.in);
        String ca = scanner.nextLine();
        String su = scanner.nextLine();
        String pr = scanner.nextLine();
        float price = scanner.nextFloat();
        scanner.nextLine();
        String de = scanner.nextLine();
        int av = scanner.nextInt();
        scanner.nextLine();
        hm.put(ca, hm.put(su, pr));
        
        
    }
    
}
