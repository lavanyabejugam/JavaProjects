package RepositoryLayer;

import DomainLayer.Models.LoginModel;
import DomainLayer.Models.RegistrationModel;

class AuthenticationRepo implements IAuthenticateRepo {

    /**
     * Method to validate login
     * @param loginModel
     * @return 
     */
    @Override
    public boolean validateLogin(LoginModel loginModel) {

        return DataSource.getUserList().stream().anyMatch(m -> m.getEmail().equals(loginModel.getEmail()) && m.getPassword().equals(loginModel.getPassword()));
    }

    /**
     * Method to validate given mail-ID
     * @param email
     * @return 
     */
    @Override
    public boolean validateEmail(String email) {
        return !DataSource.getUserList().stream().anyMatch(m -> m.getEmail().equals(email));
    }

    /**
     * Method to check whether admin has login
     * @param loginModel
     * @return 
     */
    @Override
    public boolean isAdmin(LoginModel loginModel) {
        for (RegistrationModel b : DataSource.getUserList()) {

            if ((b.getEmail()).equals(loginModel.getEmail())) {
                return b.isIsAdmin();
            }
        }
        return false;
    }
}
