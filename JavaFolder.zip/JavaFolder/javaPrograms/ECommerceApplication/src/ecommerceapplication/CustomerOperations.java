package ecommerceapplication;

import BusinessLayer.FactoryBusiness;
import BusinessLayer.IProductBusiness;
import DomainLayer.Enum.CustomerOptions;
import DomainLayer.StringLiterals;
import java.util.Scanner;

public class CustomerOperations {

    IProductBusiness _productBusiness;
    FactoryBusiness _factoryBusinessObj;

    public CustomerOperations() {
        _factoryBusinessObj = new FactoryBusiness();
    }
    
    /**
     * Method to show customer operations and to perform customer operations
     */
    public void showOperations(){
        Scanner scanner = new Scanner(System.in);
        String productName;
        CustomerOptions option;
        do {
            System.out.println(StringLiterals.CUSTOMERCHOICE);
            System.out.println(StringLiterals.MOVETOCART);
            System.out.println(StringLiterals.BUY);
            System.out.println(StringLiterals.EXITOPTION);
            option = CustomerOptions.valueOf(scanner.nextInt());
            scanner.nextLine();
            switch (option) {
                case MOVETOCART:
                    _productBusiness = _factoryBusinessObj.product();
                    System.out.println(StringLiterals.AVALIABLEPRODUCT);
                    _productBusiness.display();
                    System.out.println(StringLiterals.SELECTTOMOVETOCART);
                    productName = scanner.nextLine();
                    this.moveItemToCart(productName);
                    break;
                case BUY:
                    _productBusiness = _factoryBusinessObj.product();
                    _productBusiness.display();
                    System.out.println(StringLiterals.SELECTTOBUY);
                    productName = scanner.nextLine();
                    this.buyProduct(productName);
                    System.out.println("Your product will be delivered in 6 days :" + productName);
                    break;
                default :
                    System.out.println(StringLiterals.INVALIDCHOICE);
            }
        } while (option != CustomerOptions.EXIT);
    }
    
    /**
     * Method to move a product into cart-list
     * @param productName 
     */
    void moveItemToCart(String productName) { 
        _productBusiness = _factoryBusinessObj.product();
        _productBusiness.moveItemToCart(productName);
    }
    
    /**
     * Method to buy a particular product
     * @param productName 
     */
    void buyProduct(String productName)
    {
        _productBusiness = _factoryBusinessObj.product();
        _productBusiness.moveItemToCart(productName);
    }
}
