package BusinessLayer;

import DomainLayer.Models.RegistrationModel;

public class Validations {

    /**
     * Method for validating given details
     * @param registerModel
     * @return 
     */
    public static boolean validate(RegistrationModel registerModel) {
        return validateEmail(registerModel.getEmail()) && validatePassword(registerModel.getPassword()) && validateFirstName(registerModel.getFirstName()) && validateLastName(registerModel.getLastName());
    }

    /**
     * Method for validating given mail-ID
     * @param email
     * @return 
     */
    public static boolean validateEmail(String email) {
        IAuthenticationBusiness authenticationBusiness;
        FactoryBusiness factoryBusiness = new FactoryBusiness();
        authenticationBusiness = factoryBusiness.authenticate();
        boolean Flag = false;
        if (email.contains("@") && email.contains(".com") && authenticationBusiness.validateEmail(email)) {
            Flag = true;
        }
        return Flag;
    }

    /**
     * Method for validating given password
     * @param password
     * @return 
     */
    public static boolean validatePassword(String password) {
        int validConditions = 0;
        if (password.length() < 5) {
            return false;
        }
        for (char c : password.toCharArray()) {
            if (c >= 'a' && c <= 'z') {
                validConditions++;
                break;
            }
        }
        for (char c : password.toCharArray()) {
            if (c >= 'A' && c <= 'Z') {
                validConditions++;
                break;
            }
        }
        for (char c : password.toCharArray()) {
            if (c >= '0' && c <= '9') {
                validConditions++;
                break;
            }
        }
        return validConditions == 3;
    }

    /**
     * Method for validating given name
     * @param name
     * @return 
     */
    public static boolean validateFirstName(String name) {
        return name.length() > 0;
    }

    /**
     * Method for validating given name
     * @param name
     * @return 
     */
    public static boolean validateLastName(String name) {
        return name.length() > 0;
    }

}
