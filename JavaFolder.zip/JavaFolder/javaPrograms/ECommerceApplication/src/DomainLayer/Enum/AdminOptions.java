package DomainLayer.Enum;

import java.util.*;

public enum AdminOptions {
    ADDPRODUCT(1),
    DELETEPRODUCT(2),
    UPDATE(3),
    ADDCATEGORY(4),
    ADDSUBCATEGORY(5),
    ADDSUBSUBCATEGORY(6),
    EXIT(7);
    private int value;
    private static final Map map = new HashMap<>();

    private AdminOptions(int value) {
        this.value = value;
    }

    static {
        for (AdminOptions adminOptions : AdminOptions.values()) {
            map.put(adminOptions.value, adminOptions);
        }
    }

    public static AdminOptions valueOf(int adminOptions) {
        return (AdminOptions) map.get(adminOptions);
    }
}
