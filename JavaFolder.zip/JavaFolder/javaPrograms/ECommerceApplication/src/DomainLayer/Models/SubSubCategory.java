package DomainLayer.Models;

import java.util.ArrayList;
import java.util.List;

public class SubSubCategory {

    
    private String productSubSubCategory;
    private static final List<ProductModel> productModel= new ArrayList<>();

    /**
     * @return the productSubSubCategory
     */
    public String getProductSubSubCategory() {
        return productSubSubCategory;
    }

    /**
     * @param productSubSubCategory the productSubSubCategory to set
     */
    public void setProductSubSubCategory(String productSubSubCategory) {
        this.productSubSubCategory = productSubSubCategory;
    }
    
    /**
     * @return the _productModel
     */
    public List<ProductModel> getProductModel() {
        return productModel;
    }

    /**
     * @param aProductModel the _productModel to set
     */
    public void setProductModel(List<ProductModel> aProductModel) {
        this.productModel.add((ProductModel)aProductModel);
    }
}
