package DomainLayer.Models;

import java.util.*;

public class Category { 
    
    private String productCategory;
    private static final List<SubCategory> subCategory = new ArrayList<>();

    /**
     * @return the productCategory
     */
    public String getProductCategory() {
        return productCategory;
    }

    /**
     * @param productCategory the productCategory to set
     */
    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }
    
    /**
     * @return the _subCategory
     */
    public List<SubCategory> getSubCategory() {
        return subCategory;
    }

    /**
     * @param aSubCategory the _subCategory to set
     */
    public void setSubCategory(List<SubCategory> aSubCategory) {
        this.subCategory.add((SubCategory) aSubCategory);
    }
}
