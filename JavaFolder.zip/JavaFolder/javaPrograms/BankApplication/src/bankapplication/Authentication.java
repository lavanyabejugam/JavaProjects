package bankapplication;

import BusinessLayer.*;
import DomainLayer.Models.*;
import DomainLayer.StringLiterals;
import java.util.Scanner;

public class Authentication {

    LoginModel _loginmodelObj;
    FactoryBusiness _factoryBusinessObj;
    IAuthenticationBusiness _authObj;
    IUserBusiness _userObj;
    ClerkModel clerkModel;
    CustomerModel customerModel;
    ITransactionBusiness _transactionBusiness;
    public Authentication() {
        clerkModel = new ClerkModel();
        customerModel = new CustomerModel();
        _loginmodelObj = new LoginModel();
        _factoryBusinessObj = new FactoryBusiness();
        _transactionBusiness = _factoryBusinessObj.transactions();
    }
    
    /**
     * Method to login to operate on corresponding responsibilities
     */
    public void login() {
        System.out.print(StringLiterals.ENTEREMAIL);
        Scanner scanner = new Scanner(System.in);
        _loginmodelObj.setEmail(scanner.nextLine());
        System.out.print(StringLiterals.PASSWORD);
        _loginmodelObj.setPassword(scanner.nextLine());
        _authObj = _factoryBusinessObj.authenticate();
        if (_authObj.validateLogin(_loginmodelObj)) {

            if (_authObj.isManager(_loginmodelObj)) {
                ManagerOperationClass managerOperationObj = new ManagerOperationClass();
                managerOperationObj.managerOperation();
            } else if (_authObj.isClerk(_loginmodelObj)) {
                TransactionClass transaction = new TransactionClass();
                transaction.transactions();
            } else if (_authObj.isCustomer(_loginmodelObj)) {
                TransactionClass transaction = new TransactionClass();
                transaction.transactions();
            }
        }
    }
    
    /**
     * Method to get details and to register
     */
    public void register() {
        RegistrationModel _registermodelObj = new RegistrationModel();
        Scanner scanner = new Scanner(System.in);
        System.out.print(StringLiterals.FIRSTNAME);
        _registermodelObj.setFirstName(scanner.nextLine());

        System.out.print(StringLiterals.LASTNAME);
        _registermodelObj.setLastName(scanner.nextLine());

        System.out.print(StringLiterals.ENTEREMAIL);
        _registermodelObj.setEmail(scanner.nextLine());

        System.out.println(StringLiterals.VALIDPASSWORD);
        System.out.print(StringLiterals.PASSWORD);
        _registermodelObj.setPassword(scanner.nextLine());

        _registermodelObj.setIsManager(true);
        if (Validations.validate(_registermodelObj)) {
            _userObj = _factoryBusinessObj.user();
            _userObj.setUserDetails(_registermodelObj);
        }
    }
}
