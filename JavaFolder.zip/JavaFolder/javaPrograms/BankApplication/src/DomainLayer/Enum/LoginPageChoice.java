package DomainLayer.Enum;

import java.util.HashMap;
import java.util.Map;

public enum LoginPageChoice {
    LOGIN(1),
    REGISTER(2),
    EXIT(3);
    private int value;
    private static final Map map = new HashMap<>();

    private LoginPageChoice(int value) {
        this.value = value;
    }

    static {
        for (LoginPageChoice loginPageChoice : LoginPageChoice.values()) {
            Object put = map.put(loginPageChoice.value, loginPageChoice);
        }
    }

    public static LoginPageChoice valueOf(int loginPageChoice) {
        return (LoginPageChoice) map.get(loginPageChoice);
    }

}
