package DomainLayer.Enum;

import java.util.HashMap;
import java.util.Map;

public enum Transaction {
    VIEWTRANSACTION(1),
    DEPOSIT(2),
    WITHDRAW(3),
    CHECKBALANCE(4),
    EXIT(5);
    private int value;
    private static final Map map = new HashMap<>();

    private Transaction(int value) {
        this.value = value;
    }

    static {
        for (Transaction transaction : Transaction.values()) {
            Object put = map.put(transaction.value, transaction);
        }
    }

    public static Transaction valueOf(int transaction) {
        return (Transaction) map.get(transaction);
    }

}
