package RepositoryLayer;

import DomainLayer.Models.CustomerModel;
import DomainLayer.StringLiterals;
import java.util.List;

class TransactionRepo implements ITransactionRepo{
    
    /**
     * Method to deposit given amount into the given customer account
     * @param accountNo
     * @param amount 
     */
    @Override
    public void deposit(String accountNo, int amount) {
        if (amount != 0) {
            DataSource._customerList.stream().filter((b) -> (b.getAccountNumber().equals(accountNo))).map((b) -> {
                b.setBalance(b.getBalance() + amount);
                return b;
            }).forEach((b) -> {
                b.setPreviousTransaction(StringLiterals.DEPOSITED + amount);
            });
        }
    }
    
    /**
     * Method to withdraw given amount from given customer account 
     * @param accountNo
     * @param amount 
     */
    @Override
    public void withdraw(String accountNo, int amount) {
        if (amount != 0) {

            DataSource._customerList.stream().filter((b) -> (b.getAccountNumber().equals(accountNo))).map((b) -> {
                b.setBalance(b.getBalance() - amount);
                return b;
            }).forEach((b) -> {
                b.setPreviousTransaction(StringLiterals.WITHDRAWN + amount);
            });
        }
    }
    
    /**
     * Method to return all previous transactions made by a particular customer
     * @param accountNo
     * @return 
     */
    @Override
    public List<String> getPreviousTransaction(String accountNo) {
        for (CustomerModel b : DataSource._customerList) {
            if (b.getAccountNumber().equals(accountNo)) {
                return b.getPreviousTransaction();
            }
        }
        return null;
    }
    
    /**
     * Method to return total balance of a particular customer
     * @param accountNo
     * @return 
     */
    @Override
    public int getBalance(String accountNo)
    {
        for (CustomerModel b : DataSource._customerList) {
            if (b.getAccountNumber().equals(accountNo)) {
                return b.getBalance();
            }
        }
        return 0;
    }
}
