package RepositoryLayer;

import DomainLayer.Models.ClerkModel;
import DomainLayer.Models.CustomerModel;
import DomainLayer.Models.LoginModel;
import DomainLayer.Models.RegistrationModel;

class AuthenticationRepo implements IAuthenticateRepo {
    
    /**
     * Method to validate login
     * @param loginModel
     * @return 
     */
    @Override
    public boolean validateLogin(LoginModel loginModel) {

        return ((DataSource._userList.stream().anyMatch(m -> m.getEmail().equals(loginModel.getEmail()) && m.getPassword().equals(loginModel.getPassword())))
                || (DataSource._customerList.stream().anyMatch(m -> m.getEmail().equals(loginModel.getEmail()) && m.getPassword().equals(loginModel.getPassword())))
                || (DataSource._clerkList.stream().anyMatch(m -> m.getEmail().equals(loginModel.getEmail()) && m.getPassword().equals(loginModel.getPassword()))));

    }
    
    /**
     * Method to validate given mail-ID
     * @param email
     * @return 
     */
    @Override
    public boolean validateEmail(String email) {
        return !DataSource._userList.stream().anyMatch(m -> m.getEmail().equals(email));
    }
    
    /**
     * Method to check whether manager has login
     * @param loginModel
     * @return 
     */
    @Override
    public boolean isManager(LoginModel loginModel) {
        for (RegistrationModel b : DataSource._userList) {

            if ((b.getEmail()).equals(loginModel.getEmail())) {
                return b.isIsManager();
            }
        }
        return false;
    }
    
    /**
     * Method to check whether clerk has login
     * @param loginModel
     * @return 
     */
    @Override
    public boolean isClerk(LoginModel loginModel) {
        for (ClerkModel b : DataSource._clerkList) {

            if ((b.getEmail()).equals(loginModel.getEmail())) {
                return b.getIsClerk();
            }
        }
        return false;
    }
    
    /**
     * Method to check whether customer has login
     * @param loginModel
     * @return 
     */
    @Override
    public boolean isCustomer(LoginModel loginModel) {
        for (CustomerModel b : DataSource._customerList) {

            if ((b.getEmail()).equals(loginModel.getEmail())) {
                return b.getIsCustomer();
            }
        }
        return false;
    }
}
