/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;
//class Shape1
//{
//    static void draw()
//    {
//        System.out.println("Parent");
//    }
//}
//
//class Shape2 extends Shape1
//{ 
//    //@Override
//    static void draw()
//    {
//        System.out.println("child");
//    }
//}
interface InterfaceX 
{ 
	public int geek(); 
} 
interface InterfaceY 
{ 
	public int geek(); 
}
class Testing implements InterfaceX, InterfaceY 
{ 
    public int geek() 
	{ 
		return 1; 
	} 
        
        
}

/**
 *
 * @author lavanya.bejugam
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Testing s = new Testing();
        int k = ((InterfaceX) s).geek();
        int a = ((InterfaceY) s).geek();
        System.out.println(" k"+k);
        System.out.println(" a"+a);
        int x = s.geek(); 
        System.out.println(" x"+x);
    }
    
}
//abstract class Shape{
//    final int b=0;
//   public void display(){
//     System.out.println("This is display method");
//   }
//   abstract public void calculateArea();
//}
//class Rectangle extends Shape{
//   //super.b=9;
//   @Override
//  public void calculateArea(){}
//}
//public class JavaApplication3 {
////
////    /**
////     * @param args the command line arguments
////     */
//   public static void main(String[] args) {
//      Rectangle shape = new Rectangle();
//      shape.calculateArea();
//      int xx = shape.b;
//   }
//}
//   

