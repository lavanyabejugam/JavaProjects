package RepositoryLayer;

import java.util.List;

public interface ITransactionRepo {

    public void deposit(String accountNo, int amount);

    public void withdraw(String accountNo, int amount);

    public List<String> getPreviousTransaction(String accountNo);

    public int getBalance(String accountNo);
}
