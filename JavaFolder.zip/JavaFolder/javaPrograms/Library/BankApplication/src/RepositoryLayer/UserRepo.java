package RepositoryLayer;

import DomainLayer.Models.*;

class UserRepo implements IUserRepo {

    @Override
    public void setUserDetails(RegistrationModel rmObj) {
        DataSource._userList.add(rmObj);
    }

    @Override
    public void setCustomerDetails(CustomerModel cObj) {
        DataSource._customerList.add(cObj);
    }

    @Override
    public void setClerkDetails(ClerkModel cObj) {
        DataSource._clerkList.add(cObj);
    }
}
