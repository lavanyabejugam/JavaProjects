package RepositoryLayer;

import DomainLayer.Models.*;

public interface IUserRepo {

    void setUserDetails(RegistrationModel rmObj);

    void setCustomerDetails(CustomerModel robj);

    void setClerkDetails(ClerkModel robj);
}
