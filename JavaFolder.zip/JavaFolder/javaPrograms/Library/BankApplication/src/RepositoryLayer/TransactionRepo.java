package RepositoryLayer;

import DomainLayer.Models.CustomerModel;
import DomainLayer.StringLiterals;
import java.util.List;

class TransactionRepo implements ITransactionRepo{

    @Override
    public void deposit(String accountNo, int amount) {
        if (amount != 0) {
            DataSource._customerList.stream().filter((b) -> (b.getAccountNumber().equals(accountNo))).map((b) -> {
                b.setBalance(b.getBalance() + amount);
                return b;
            }).forEach((b) -> {
                b.setPreviousTransaction(StringLiterals._deposited + amount);
            });
        }
    }

    @Override
    public void withdraw(String accountNo, int amount) {
        if (amount != 0) {

            DataSource._customerList.stream().filter((b) -> (b.getAccountNumber().equals(accountNo))).map((b) -> {
                b.setBalance(b.getBalance() - amount);
                return b;
            }).forEach((b) -> {
                b.setPreviousTransaction(StringLiterals._withDrawn + amount);
            });
        }
    }
    @Override
    public List<String> getPreviousTransaction(String accountNo) {
        for (CustomerModel b : DataSource._customerList) {
            if (b.getAccountNumber().equals(accountNo)) {
                return b.getPreviousTransaction();
            }
        }
        return null;
    }
    @Override
    public int getBalance(String accountNo)
    {
        for (CustomerModel b : DataSource._customerList) {
            if (b.getAccountNumber().equals(accountNo)) {
                return b.getBalance();
            }
        }
        return 0;
    }
}
