package BusinessLayer;

import DomainLayer.Models.*;

public interface IUserBusiness {

    void setUserDetails(RegistrationModel robj);

    void setCustomerDetails(CustomerModel robj);

    void setClerkDetails(ClerkModel robj);

}
