package BusinessLayer;

import DomainLayer.Models.LoginModel;

public interface IAuthenticationBusiness {

    boolean validateLogin(LoginModel loginModel);

    boolean isManager(LoginModel loginModel);

    boolean isClerk(LoginModel loginModel);

    boolean isCustomer(LoginModel loginModel);
}
