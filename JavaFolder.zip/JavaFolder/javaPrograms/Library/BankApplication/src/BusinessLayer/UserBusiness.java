package BusinessLayer;

import DomainLayer.Models.*;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IUserRepo;

class UserBusiness implements IUserBusiness {

    IUserRepo _userObj;

    public UserBusiness() {
        _userObj = FactoryRepo.userDetails();
    }

    @Override
    public void setUserDetails(RegistrationModel robj) {

        _userObj.setUserDetails(robj);
    }
    
    @Override
    public void setCustomerDetails(CustomerModel cobj)
    {
        _userObj.setCustomerDetails(cobj);
    }
    @Override
    public void setClerkDetails(ClerkModel cobj)
    {
        _userObj.setClerkDetails(cobj);
    }
}
