package BusinessLayer;

import java.util.List;

public interface ITransactionBusiness {
    
    public void deposit(String accountNo, int amount);

    public void withdraw(String accountNo, int amount);

    public List<String> getPreviousTransaction(String accountNo);

    public int getBalance(String accountNo);
}
