package bankapplication;

import BusinessLayer.*;
import DomainLayer.Enum.ManagerChoice;
import DomainLayer.Enum.Transaction;
import DomainLayer.Models.*;
import DomainLayer.StringLiterals;
import java.util.List;
import java.util.Scanner;

public class Authentication {

    LoginModel _loginmodelObj;
    FactoryBusiness _factoryBusinessObj;
    IAuthenticationBusiness _authObj;
    IUserBusiness _userObj;
    ClerkModel clerkModel;
    CustomerModel customerModel;
    ITransactionBusiness _transactionBusiness;
    public Authentication() {
        clerkModel = new ClerkModel();
        customerModel = new CustomerModel();
        _loginmodelObj = new LoginModel();
        _factoryBusinessObj = new FactoryBusiness();
        _transactionBusiness = _factoryBusinessObj.transactions();
    }

    void login() {
        System.out.print(StringLiterals._email);
        Scanner scanner = new Scanner(System.in);
        _loginmodelObj.setEmail(scanner.nextLine());
        System.out.print(StringLiterals._password);
        _loginmodelObj.setPassword(scanner.nextLine());
        _authObj = _factoryBusinessObj.authenticate();
        if (_authObj.validateLogin(_loginmodelObj)) {

            if (_authObj.isManager(_loginmodelObj)) {
                ManagerChoice choice;
                do {
                    System.out.println(StringLiterals._managerChoice);
                    System.out.println(StringLiterals._addClerk);
                    System.out.println(StringLiterals._addCustomer);
                    System.out.println(StringLiterals._exit);
                    choice = ManagerChoice.valueOf(scanner.nextInt());
                    scanner.nextLine();
                    switch (choice) {
                        case AddClerk:
                            System.out.print(StringLiterals._clerkFN);
                            clerkModel.setFirstName(scanner.nextLine());
                            System.out.print(StringLiterals._clerkLN);
                            clerkModel.setLastName(scanner.nextLine());
                            System.out.print(StringLiterals._clerkEmail);
                            clerkModel.setEmail(scanner.nextLine());
                            System.out.print(StringLiterals._clerkPassword);
                            clerkModel.setPassword(scanner.nextLine());
                            clerkModel.setIsClerk(true);
                            _userObj = _factoryBusinessObj.user();
                            _userObj.setClerkDetails(clerkModel);
                            break;
                        case AddCustomer:
                            System.out.print(StringLiterals._customerFN);
                            customerModel.setFirstName(scanner.nextLine());
                            System.out.print(StringLiterals._customerLN);
                            customerModel.setLastName(scanner.nextLine());
                            System.out.print(StringLiterals._customerEmail);
                            customerModel.setEmail(scanner.nextLine());
                            System.out.print(StringLiterals._customerPassword);
                            customerModel.setPassword(scanner.nextLine());
                            System.out.print(StringLiterals._customerAccNo);
                            customerModel.setAccountNumber(scanner.nextLine());
                            customerModel.setIsCustomer(true);
                            _userObj = _factoryBusinessObj.user();
                            _userObj.setCustomerDetails(customerModel);
                            break;
                    }
                } while (choice != ManagerChoice.Exit);
            } else if (_authObj.isClerk(_loginmodelObj)) {
                ClerkOperation clerkOperation = new ClerkOperation();
                clerkOperation.showOperation();
            } else if (_authObj.isCustomer(_loginmodelObj)) {
                Transaction choice;
                String accountNo;
                do
                {
                System.out.println(StringLiterals._viewTransaction);
                System.out.println(StringLiterals._deposit);
                System.out.println(StringLiterals._withdraw);
                System.out.println(StringLiterals._checkBalance);
                System.out.println(StringLiterals._Exit);
                choice = Transaction.valueOf(scanner.nextInt());
                scanner.nextLine();
                switch (choice) {
                    case ViewTransaction:
                        System.out.print(StringLiterals._accountNo);
                        accountNo = scanner.nextLine();
                        System.out.println(_transactionBusiness.getPreviousTransaction(accountNo));
                        break;
                    case Deposit:
                        System.out.print(StringLiterals._amountDeposit);
                        int amount = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print(StringLiterals._accountNo);
                        accountNo = scanner.nextLine();
                        _transactionBusiness.deposit(accountNo, amount);
                        break;
                    case Withdraw:
                        System.out.print(StringLiterals._amountWithdraw);
                        int withdraw = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print(StringLiterals._accountNo);
                        accountNo = scanner.nextLine();
                        _transactionBusiness.withdraw(accountNo, withdraw);
                        break;
                    case CheckBalance:
                        System.out.print(StringLiterals._accountNo);
                        accountNo = scanner.nextLine();
                        System.out.println(_transactionBusiness.getBalance(accountNo));
                        break;
                }
                }while(choice != Transaction.Exit);
            }
        }
    }

    void register() {
        RegistrationModel _registermodelObj = new RegistrationModel();
        Scanner scanner = new Scanner(System.in);
        System.out.print(StringLiterals._firstName);
        _registermodelObj.setFirstName(scanner.nextLine());

        System.out.print(StringLiterals._lastName);
        _registermodelObj.setLastName(scanner.nextLine());

        System.out.print(StringLiterals._email);
        _registermodelObj.setEmail(scanner.nextLine());

        System.out.println(StringLiterals._validPassword);
        System.out.print(StringLiterals._password);
        _registermodelObj.setPassword(scanner.nextLine());

        _registermodelObj.setIsManager(true);
        if (Validations.validate(_registermodelObj)) {
            _userObj = _factoryBusinessObj.user();
            _userObj.setUserDetails(_registermodelObj);
        }
    }
}
