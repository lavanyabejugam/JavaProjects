package bankapplication;

import BusinessLayer.ITransactionBusiness;
import java.util.List;

public class ClerkOperation {

    ITransactionBusiness _transactionBusiness;
        

    public List<String> getPreviousTransaction(String accountNo) {
        return _transactionBusiness.getPreviousTransaction(accountNo);
    }

    public void deposit(String accountNo, int amount) {
        _transactionBusiness.deposit(accountNo, amount);
    }

    public void withdraw(String accountNo, int withdraw) {
        _transactionBusiness.withdraw(accountNo, withdraw);
    }

    public int getBalance(String accountNo) {

        return _transactionBusiness.getBalance(accountNo);
    }

}
