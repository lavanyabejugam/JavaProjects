package DomainLayer.Models;

import java.util.ArrayList;
import java.util.List;

public class CustomerModel {
    private String Email;
    private String Password;
    private String FirstName;
    private String LastName;
    private String AccountNumber;
    private int Balance;
    private List<String> PreviousTransaction = new ArrayList<>();
    private Boolean IsCustomer;
    /**
     * @return the Email
     */
    public String getEmail() {
        return Email;
    }

    /**
     * @param Email the Email to set
     */
    public void setEmail(String Email) {
        this.Email = Email;
    }

    /**
     * @return the Password
     */
    public String getPassword() {
        return Password;
    }

    /**
     * @param Password the Password to set
     */
    public void setPassword(String Password) {
        this.Password = Password;
    }

    /**
     * @return the FirstName
     */
    public String getFirstName() {
        return FirstName;
    }

    /**
     * @param FirstName the FirstName to set
     */
    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    /**
     * @return the LastName
     */
    public String getLastName() {
        return LastName;
    }

    /**
     * @param LastName the LastName to set
     */
    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    /**
     * @return the AccountNumber
     */
    public String getAccountNumber() {
        return AccountNumber;
    }

    /**
     * @param AccountNumber the AccountNumber to set
     */
    public void setAccountNumber(String AccountNumber) {
        this.AccountNumber = AccountNumber;
    }

    /**
     * @return the Balance
     */
    public int getBalance() {
        return Balance;
    }

    /**
     * @param Balance the Balance to set
     */
    public void setBalance(int Balance) {
        this.Balance = Balance;
    }

    

    /**
     * @return the IsCustomer
     */
    public Boolean getIsCustomer() {
        return IsCustomer;
    }

    /**
     * @param IsCustomer the IsCustomer to set
     */
    public void setIsCustomer(Boolean IsCustomer) {
        this.IsCustomer = IsCustomer;
    }

    /**
     * @return the PreviousTransaction
     */
    public List<String> getPreviousTransaction() {
        return PreviousTransaction;
    }

    /**
     * @param PreviousTransaction the PreviousTransaction to set
     */
    public void setPreviousTransaction(String previousTransaction) {
        PreviousTransaction.add(previousTransaction);
    }
}
