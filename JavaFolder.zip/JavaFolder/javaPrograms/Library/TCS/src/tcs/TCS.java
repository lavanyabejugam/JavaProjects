/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tcs;

import java.util.*;
import java.util.Scanner;

/**
 *
 * @author lavanya.bejugam
 */
public class TCS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Vehicle vehicle = new Vehicle();
        TCS tcs = new TCS();
        Map<Integer,Vehicle> map = new HashMap<Integer,Vehicle>();
        System.out.println("Enter");
        Scanner s = new Scanner(System.in);
        for(int i = 0; i < 3; i++)
        {
            Vehicle vehicle = new Vehicle();
            int id = s.nextInt();
        s.nextLine();
        
        vehicle.setFuel(s.nextLine());
        vehicle.setMileage(s.nextInt());
        s.nextLine();
        vehicle.setName(s.nextLine());
        
        map.put(id, vehicle);
        }
        
        Map<Integer, Vehicle> mmm = tcs.getVehicle(s.nextLine(), map);
        for (Map.Entry<Integer,Vehicle> t : mmm.entrySet()){  
            
                System.out.println("after");
                System.out.println(t.getKey()+" "+t.getValue().getFuel()+" "+t.getValue().getName());
                
        }
                
    }
    public Map<Integer, Vehicle> getVehicle(String fuel, Map<Integer, Vehicle> map)
    {
        Map<Integer, Vehicle> map1 = new HashMap<>();
        for (Map.Entry<Integer,Vehicle> entry : map.entrySet()){ 
            
            if(entry.getValue().getFuel().equals(fuel))
            {
                
                map1.put(entry.getKey(), entry.getValue());
            }
        }
        List<Map.Entry<Integer, Vehicle> > list = new LinkedList<Map.Entry<Integer, Vehicle> >(map1.entrySet()); 
  
        // Sort the list 
        Collections.sort(list, new Comparator<Map.Entry<Integer, Vehicle> >() { 
            public int compare(Map.Entry<Integer, Vehicle> o1,  
                               Map.Entry<Integer, Vehicle> o2) 
            { 
                return (String.valueOf(o1.getValue().getMileage()).compareTo(String.valueOf(o2.getValue().getMileage()))); 
            } 
        }); 
          
        // put data from sorted list to hashmap  
        HashMap<Integer, Vehicle> temp = new LinkedHashMap<Integer, Vehicle>(); 
        for (Map.Entry<Integer, Vehicle> aa : list) { 
            temp.put(aa.getKey(), aa.getValue()); 
        } 
        return temp; 
     
        
    }
    
}
