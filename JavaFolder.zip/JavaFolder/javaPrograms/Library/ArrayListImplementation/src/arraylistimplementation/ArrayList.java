package arraylistimplementation;

import java.util.Arrays;

public class ArrayList<E> {

    private transient Object[] studentData = new Object[10];
    private static final int MAX_ARRAY_SIZE = Integer.MAX_VALUE - 8;
    private int size;
    
    public int size() {
        return size;
    }
    public E get(int index) {
        return (E) studentData[index];
    }
    
    /**
     * Method to add data into ArrayList.
     * @param e
     * @return 
     */
    public boolean add(E e) {
        increaseCapacity(size + 1);
        studentData[size++] = e;
        return true;
    }
    
    /**
     * Method to increase capacity when required capacity is greater than MAX_ARRAY_SIZE
     * @param minCapacity 
     */
    public void increaseCapacity(int minCapacity) {
        int newCapacity = minCapacity;
        if (newCapacity - MAX_ARRAY_SIZE > 0) {
            newCapacity = hugeCapacity(minCapacity);
        }
        studentData = Arrays.copyOf(studentData, newCapacity);
        
    }
    
    /**
     * Method to increase capacity when required capacity is greater than MAX_ARRAY_SIZE
     * @param minCapacity
     * @return 
     */
    private static int hugeCapacity(int minCapacity) {
        return (minCapacity > MAX_ARRAY_SIZE) ? Integer.MAX_VALUE : MAX_ARRAY_SIZE;
    }
    
    /**
     * Method to remove data corresponding to given index from the ArrayList. 
     * @param index
     * @param list 
     */
    public void remove(int index, ArrayList<StudentInfo> list) {
        if(index < size)
        {
            list.studentData[index] = null;
            int j = 0;
            for(int i = 0; i < list.size(); i++)
            {
                if(list.studentData[i] != null)
                {
                    list.studentData[j] = list.studentData[i];
                    j++;
                }
            }
            --size;
        }
    }
    
    /**
     * Method to display all the data in ArrayList.
     * @param list 
     */
    public void printArrayListValues(ArrayList<StudentInfo> list)
    {
        for (int i = 0; i < list.size(); i++) 
        {           
            StudentInfo data = list.get(i); 
            System.out.println(data.getId() + " " + data.getName () + " "+data.getDepartment()); 
        } 
    }
}
