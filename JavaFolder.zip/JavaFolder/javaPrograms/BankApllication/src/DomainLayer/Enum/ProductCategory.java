package DomainLayer.Enum;

import java.util.*;

public enum ProductCategory {
    Mobiles(1),
    Watches(2);
    private int value;
    private static Map map = new HashMap<>();

    private ProductCategory(int value) {
        this.value = value;
    }

    static {
        for (ProductCategory productCategory : ProductCategory.values()) {
            map.put(productCategory.value, productCategory);
        }
    }

    public static ProductCategory valueOf(int productCategory) {
        return (ProductCategory) map.get(productCategory);
    }
}
