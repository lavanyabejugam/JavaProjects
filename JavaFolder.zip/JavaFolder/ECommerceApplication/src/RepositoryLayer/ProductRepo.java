package RepositoryLayer;

import DomainLayer.Models.*;

public class ProductRepo implements IProductRepo {

    @Override
    public void display() {
        System.out.println("Avaliable Products");
        for (ProductModel b : DataSource._productList) {
            System.out.println(b.getProductName() + " " + b.getPrice() + " " + b.getDescription() + " " + b.getAvaliableStock());
        }
    }

    @Override
    public void setProductDetails(ProductModel pObj) {
        DataSource._productList.add(pObj);

    }

    @Override
    public void deleteItems(String ItemToBeRemoved) {
        for (ProductModel b : DataSource._productList) {
            if ((b.getProductName()).equals(ItemToBeRemoved) && (b.getAvaliableStock() == 1)) {
                DataSource._productList.remove(b);
            } else if ((b.getProductName()).equals(ItemToBeRemoved) && (b.getAvaliableStock() > 1)) {
                b.setAvaliableStock(b.getAvaliableStock() - 1);
            }
        }

    }

    @Override
    public void updateItem(String productName, float price) {
        for (ProductModel b : DataSource._productList) {
            if (b.productName.equals(productName)) {
                b.price = price;
            }
        }
    }

    @Override
    public void moveItemToCart(String productName) {
        for (ProductModel b : DataSource._productList) {
            if (b.productName.equals(productName)) {
                DataSource._cartList.add(b);
            }
        }
    }
}
