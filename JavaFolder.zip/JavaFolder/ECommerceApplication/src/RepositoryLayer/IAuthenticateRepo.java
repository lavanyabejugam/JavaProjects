package RepositoryLayer;

import DomainLayer.Models.LoginModel;

public interface IAuthenticateRepo {

    boolean validateLogin(LoginModel loginModel);

    boolean validateEmail(String email);

    boolean isAdmin(LoginModel loginModel);
}
