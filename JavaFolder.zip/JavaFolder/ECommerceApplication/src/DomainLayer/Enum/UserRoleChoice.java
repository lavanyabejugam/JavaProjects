package DomainLayer.Enum;

public enum UserRoleChoice { 
    Admin, 
    Other
}  

