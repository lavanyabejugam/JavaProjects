package DomainLayer.Enum;

import java.util.*;

public enum AdminOptions {
    Add(1),
    Delete(2),
    Update(3),
    Exit(4);
    private int value;
    private static Map map = new HashMap<>();

    private AdminOptions(int value) {
        this.value = value;
    }

    static {
        for (AdminOptions adminOptions : AdminOptions.values()) {
            map.put(adminOptions.value, adminOptions);
        }
    }

    public static AdminOptions valueOf(int adminOptions) {
        return (AdminOptions) map.get(adminOptions);
    }
}
