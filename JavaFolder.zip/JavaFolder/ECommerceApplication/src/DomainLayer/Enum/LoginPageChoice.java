package DomainLayer.Enum;

import java.util.*;

public enum LoginPageChoice {

    Login(1),
    Register(2),
    Exit(3);
    private int value;
    private static Map map = new HashMap<>();

    private LoginPageChoice(int value) {
        this.value = value;
    }

    static {
        for (LoginPageChoice loginPageChoice : LoginPageChoice.values()) {
            map.put(loginPageChoice.value, loginPageChoice);
        }
    }

    public static LoginPageChoice valueOf(int loginPageChoice) {
        return (LoginPageChoice) map.get(loginPageChoice);
    }

}
