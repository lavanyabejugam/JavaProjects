package DomainLayer.Models;

public class ProductModel {

    public String productName;
    public float price;
    public String description;
    public int avaliableStock;


    /**
     * @return the productName
     */
    public String getProductName() {
        return productName;
    }

    /**
     * @param productName the productName to set
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * @return the price
     */
    public float getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(float price) {
        this.price = price;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the avaliableStock
     */
    public int getAvaliableStock() {
        return avaliableStock;
    }

    /**
     * @param avaliableStock the avaliableStock to set
     */
    public void setAvaliableStock(int avaliableStock) {
        this.avaliableStock = avaliableStock;
    }
}
