package BusinessLayer;

import DomainLayer.Models.LoginModel;

public interface IAuthenticationBusiness {

    boolean validateLogin(LoginModel loginModel);

    boolean isAdmin(LoginModel loginModel);
}
