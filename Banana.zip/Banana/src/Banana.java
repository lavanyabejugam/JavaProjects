import java.sql.PreparedStatement;

//import java.sql.Connection;
//import java.sql.DatabaseMetaData;
//import java.sql.DriverManager;
//
//public class Banana {
//	public static Connection connObj;
//    public static String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
// 
//    public static void getDbConnection() {
//        try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            connObj = DriverManager.getConnection(JDBC_URL);
//            if(connObj != null) {
//                DatabaseMetaData metaObj = (DatabaseMetaData) connObj.getMetaData();
//                System.out.println("Driver Name?= " + metaObj.getDriverName() + ", Driver Version?= " + metaObj.getDriverVersion() + ", Product Name?= " + metaObj.getDatabaseProductName() + ", Product Version?= " + metaObj.getDatabaseProductVersion());
//            }
//        } catch(Exception sqlException) {
//            sqlException.printStackTrace();
//        }
//    }
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		getDbConnection();
//
//	}
//}
import java.sql.Connection;
import java.sql.DriverManager;

public class Banana{
	public static String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
	public static void main(String[] args) throws Exception{
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection conn = DriverManager.getConnection(JDBC_URL);
		String sql = "Insert into Persons (PersonID, LastName, FirstName, Address, City) Values (?, ?, ?, ?, ?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setInt(1, 413);
		stmt.setString(2, "Lavanya");
		stmt.setString(3, "Bejugam");
		stmt.setString(4, "H.No:5");
		stmt.setString(5, "Hyderabad");
		int i=stmt.executeUpdate();  
		System.out.println(i+" records inserted"); 
		//Resultsetstmt.executeQuery();
		
		conn.close();
	}
}