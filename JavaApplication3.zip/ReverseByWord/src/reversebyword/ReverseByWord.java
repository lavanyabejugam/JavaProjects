/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reversebyword;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Stack;
/**
 *
 * @author lavanya.bejugam
 */
public class ReverseByWord {
    public static void main(String[] args)
    {
        ReverseByWord obj = new ReverseByWord();
        String str = "Hello World";
        StringBuilder reverseStr = obj.reverseByWordUsingStack(str);
        System.out.println(reverseStr);
        
        List<String> al = new ArrayList<>();
        al = obj.reverseByWord(str,al);
        StringBuilder sb = new StringBuilder();
        for(int i = al.size()-1; i>=0;i--)
        {
            sb.append(al.get(i)).append(" ");

        }
        System.out.println(sb);
    }
    public List reverseByWord(String str, List al)
    {
        int index = str.indexOf(" ");
        al.add(str.substring(0, index));
        str  = str.substring(index+1);
        if(!str.contains(" "))
        {
            al.add(str.substring(0));
            return al;
        }
        return reverseByWord(str,al);

    }
    public StringBuilder reverseByWordUsingStack(String str)
    {
        StringTokenizer st = new StringTokenizer(str);
        int countTokens = st.countTokens();
        Stack<String> WordStack = new Stack<>();
        while (st.hasMoreTokens()) {
            String temp = st.nextToken();     
            WordStack.push(temp);
            if(countTokens != 1){
                WordStack.push(" ");
                countTokens--;
            }
        }
        StringBuilder result = new StringBuilder();
        while (!WordStack.empty()) {
            result.append(WordStack.pop());
        }
        return result;
    }
}
