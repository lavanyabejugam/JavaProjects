package usermarkerinterface;

public interface Cheque {
    
}
