package usermarkerinterface;


public class UserMarkerInterface {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        PaymentByCash one  = new PaymentByCash();
	if(one instanceof Cash)
	{           
            one.paymentByCash();
	}
 
        PaymentByCheque cheque = new PaymentByCheque();
        if(cheque instanceof Cheque)
        {  
            cheque.paymentByCheque();
        }
    }
    
}
