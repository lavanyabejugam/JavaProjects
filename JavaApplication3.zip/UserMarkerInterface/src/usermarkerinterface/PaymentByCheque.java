package usermarkerinterface;

public class PaymentByCheque implements Cheque{
    void paymentByCheque()
    {
        System.out.println("Payment is done by cheque");
    }
}
