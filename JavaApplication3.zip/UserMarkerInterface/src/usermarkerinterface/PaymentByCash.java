package usermarkerinterface;

public class PaymentByCash implements Cash{
    void paymentByCash()
    {
        System.out.println("Payment is done by cash");
    }
}
