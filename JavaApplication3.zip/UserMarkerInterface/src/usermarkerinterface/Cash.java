package usermarkerinterface;

public interface Cash {
    
}
