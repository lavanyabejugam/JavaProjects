/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

abstract class Shape
{
    abstract void draw();
}

class Rectangle extends Shape
{
    @Override
    void draw()
    {
       System.out.println("Rectangle");     
    }
}
public class Javaapplication2
{
    public static void main()
    {
        Shape shape = new Rectangle();
        shape.draw();
    
    }
    
}
