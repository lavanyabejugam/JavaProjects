/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package splittingstringusingst;

/**
 *
 * @author lavanya.bejugam
 */
public class MainClass {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StringOperation stringOperation = new StringOperation();
        StringSplit obj = new StringSplit();
        stringOperation.setStr("Hello,world.com");
        obj.stringSplit(stringOperation.getStr());
        
    }
    
}
