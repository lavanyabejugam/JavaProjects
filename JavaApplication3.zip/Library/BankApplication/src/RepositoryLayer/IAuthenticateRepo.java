package RepositoryLayer;

import DomainLayer.Models.LoginModel;

public interface IAuthenticateRepo {

    boolean validateLogin(LoginModel loginModel);

    boolean validateEmail(String email);

    boolean isManager(LoginModel loginModel);

    boolean isClerk(LoginModel loginModel);

    boolean isCustomer(LoginModel loginModel);
}
