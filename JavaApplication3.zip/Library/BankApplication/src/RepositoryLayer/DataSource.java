package RepositoryLayer;

import DomainLayer.Models.*;
import java.util.*;

class DataSource {

    public static List<RegistrationModel> _userList = new ArrayList<>();
    public static List<CustomerModel> _customerList = new ArrayList<>();
    public static List<ClerkModel> _clerkList = new ArrayList<>();
}
