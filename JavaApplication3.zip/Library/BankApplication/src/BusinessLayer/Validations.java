package BusinessLayer;

import DomainLayer.Models.RegistrationModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IAuthenticateRepo;

public class Validations {

    public static boolean validate(RegistrationModel registerModel) {
        return validateEmail(registerModel.getEmail()) && validatePassword(registerModel.getPassword()) && validateFirstName(registerModel.getFirstName()) && validateLastName(registerModel.getLastName());
    }

    public static boolean validateEmail(String email) {
        IAuthenticateRepo _authObj;
        _authObj = FactoryRepo.authRepo();
        boolean Flag = false;
        if (email.contains("@") && email.contains(".com") && _authObj.validateEmail(email)) {
            Flag = true;
        }
        return Flag;
    }

    public static boolean validatePassword(String password) {
        int validConditions = 0;
        if (password.length() < 5) {
            return false;
        }
        for (char c : password.toCharArray()) {
            if (c >= 'a' && c <= 'z') {
                validConditions++;
                break;
            }
        }
        for (char c : password.toCharArray()) {
            if (c >= 'A' && c <= 'Z') {
                validConditions++;
                break;
            }
        }
        for (char c : password.toCharArray()) {
            if (c >= '0' && c <= '9') {
                validConditions++;
                break;
            }
        }
        return validConditions == 3;
    }

    public static boolean validateFirstName(String Name) {
        return Name.length() > 0;
    }

    public static boolean validateLastName(String Name) {
        return Name.length() > 0;
    }

}
