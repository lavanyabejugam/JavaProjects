package BusinessLayer;

import RepositoryLayer.FactoryRepo;
import RepositoryLayer.ITransactionRepo;
import java.util.List;

class TransactionBusiness implements ITransactionBusiness{
    
    ITransactionRepo _transactionRepoObj;
    public TransactionBusiness() {
        _transactionRepoObj = FactoryRepo.transactions();
    }
    int balance;
    int previousTransaction;
    @Override
    public void deposit(String accountNo, int amount)
    {
        _transactionRepoObj.deposit(accountNo, amount);
    }
    @Override
    public void withdraw(String accountNo, int amount)
    {
        _transactionRepoObj.withdraw(accountNo, amount);
    }
    @Override
    public List<String> getPreviousTransaction(String accountNo){
        return _transactionRepoObj.getPreviousTransaction(accountNo);
    }
    @Override
    public int getBalance(String accountNo)
    {
        return _transactionRepoObj.getBalance(accountNo);
    }
}
