package BusinessLayer;

import DomainLayer.Models.LoginModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IAuthenticateRepo;

class AuthenticationBusiness implements IAuthenticationBusiness {

    IAuthenticateRepo _authObj;

    @Override
    public boolean validateLogin(LoginModel loginModel) {
        _authObj = FactoryRepo.authRepo();
        return _authObj.validateLogin(loginModel);
    }

    @Override
    public boolean isManager(LoginModel loginModel) {
        _authObj = FactoryRepo.authRepo();
        return _authObj.isManager(loginModel);
    }

    @Override
    public boolean isClerk(LoginModel loginModel) {
        _authObj = FactoryRepo.authRepo();
        return _authObj.isClerk(loginModel);
    }

    @Override
    public boolean isCustomer(LoginModel loginModel) {
        _authObj = FactoryRepo.authRepo();
        return _authObj.isCustomer(loginModel);
    }
}
