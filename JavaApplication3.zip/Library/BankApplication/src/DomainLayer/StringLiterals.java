package DomainLayer;

public class StringLiterals {

    public static String _validPassword = "Your Password must contain atleast one captial letter, atleastone small letter and atleast one number";
    public static String _invalidLoginPassword = "Password does not match ";
    public static String _invalidEmail = "Invalid Email";
    public static String _userChoice = "User Choice :";
    public static String _email = "Enter EmailID :";
    public static String _login = "Enter 1 to Login";
    public static String _register = "Enter 2 to Register";
    public static String _exit = "Enter 3 to Exit";
    public static String _password = "Password :";
    public static String _firstName = "FirstName :";
    public static String _lastName = "LastName :";
    public static String _typeOfReg = "Type of registration";
    public static String _userRoleChoice1 = "Enter 1 to regsiter as a Manager";
    public static String _managerChoice = "Manager Choice :";
    public static String _addClerk = "Enter 1 to AddClerk";
    public static String _addCustomer = "Enter 2 to AddCustomer";
    public static String _viewTransaction = "enter 1 to view transactions";
    public static String _deposit = "enter 2 to deposit";
    public static String _withdraw = "enter 3 to withdraw";
    public static String _checkBalance = "enter 4 to Check balance";
    public static String _Exit = "enter 5 to exit";
    public static String _accountNo = "AccountNo :";
    public static String _clerkFN = "Enter clerk FirstName :";
    public static String _clerkLN = "Enter clerk LastName :";
    public static String _clerkEmail = "Enter clerk emailId :";
    public static String _clerkPassword = "Enter default password for clerk :";
    public static String _customerFN = "Enter customer FirstName :";
    public static String _customerLN = "Enter customer LastName :";
    public static String _customerEmail = "Enter customer emailId :";
    public static String _customerPassword = "Enter default password for customer :";
    public static String _customerAccNo = "Enter customer account number :";
    public static String _amountDeposit = "Enter amount to deposit :";
    public static String _amountWithdraw = "Enter amount to withdraw :";
    public static String _balance = "Avaliable balance :";
    public static String _listOfTrans = "Luist Of previous transactions :";
    public static String _deposited = "Deposited :";
    public static String _withDrawn = "WithDraw";
    
}
