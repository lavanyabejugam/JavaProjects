package DomainLayer.Enum;

import java.util.*;

public enum ManagerChoice {

    AddClerk(1),
    AddCustomer(2),
    Exit(3);
    private int value;
    private static final Map map = new HashMap<>();

    private ManagerChoice(int value) {
        this.value = value;
    }

    static {
        for (ManagerChoice managerChoice : ManagerChoice.values()) {
            Object put = map.put(managerChoice.value, managerChoice);
        }
    }

    public static ManagerChoice valueOf(int managerChoice) {
        return (ManagerChoice) map.get(managerChoice);
    }
}
