/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collatzsequence;

/**
 *
 * @author lavanya.bejugam
 */
public class CollatzSequence {

    public static void main (String[] args) {
    int max = 0;
    long num = 0;
    long result = 0;
    int chainSize = 0;
    

    for (long i = 2; i < 1000000; i++) {
        chainSize = 0;
        num = i;
        while (num != 1) {
            if (num % 2 == 0) {
                num = num / 2;
            } else {
                num = 3 * num + 1;
            }
            chainSize++;
        }
        if (chainSize > max) {
            max = chainSize;
            result = i;
        }
    }

    System.out.printf("%d, %d", result, max);
}
    
}
