/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chararraycopydemo;

/**
 *
 * @author lavanya.bejugam
 */
public class CharArrayCopyDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        char[] data = {'G', 'g', 'k', ' ', 'T', 'e', 'c', 'h'};
        String str = String.valueOf(data);
        System.out.println(str);
    }
    
}
