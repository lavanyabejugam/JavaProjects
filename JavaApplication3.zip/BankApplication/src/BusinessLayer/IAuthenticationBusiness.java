package BusinessLayer;

import DomainLayer.Models.LoginModel;

public interface IAuthenticationBusiness {
    
    /**
     * Method signature to validate login
     * @param loginModel
     * @return 
     */
    boolean validateLogin(LoginModel loginModel);
    
    /**
     * Method signature to validate email
     * @param email
     * @return 
     */
    boolean validateEmail(String email);
    /**
     * Method signature to check whether manager has login
     * @param loginModel
     * @return 
     */
    boolean isManager(LoginModel loginModel);
    
    /**
     * Method signature to check whether clerk has login
     * @param loginModel
     * @return 
     */
    boolean isClerk(LoginModel loginModel);
    
    /**
     * Method signature to check whether customer has login
     * @param loginModel
     * @return 
     */
    boolean isCustomer(LoginModel loginModel);
}
