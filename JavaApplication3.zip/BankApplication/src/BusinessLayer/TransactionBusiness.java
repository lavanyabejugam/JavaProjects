package BusinessLayer;

import RepositoryLayer.FactoryRepo;
import RepositoryLayer.ITransactionRepo;
import java.util.List;

class TransactionBusiness implements ITransactionBusiness{
    
    ITransactionRepo _transactionRepoObj;
    
    public TransactionBusiness() {
      
        _transactionRepoObj = FactoryRepo.transactions();
    }
    
    int balance;
    int previousTransaction;
    
    /**
     * Method to deposit given amount into the given customer account
     * @param accountNo
     * @param amount 
     */
    @Override
    public void deposit(String accountNo, int amount)
    {
        _transactionRepoObj.deposit(accountNo, amount);
    }
    
    /**
     * Method to withdraw given amount from given customer account 
     * @param accountNo
     * @param amount 
     */
    @Override
    public void withdraw(String accountNo, int amount)
    {
        _transactionRepoObj.withdraw(accountNo, amount);
    }
    
    /**
     * Method to return all previous transactions made by a particular customer
     * @param accountNo
     * @return 
     */
    @Override
    public List<String> getPreviousTransaction(String accountNo){
        return _transactionRepoObj.getPreviousTransaction(accountNo);
    }
    
    /**
     * Method to return total balance of a particular customer
     * @param accountNo
     * @return 
     */
    @Override
    public int getBalance(String accountNo)
    {
        return _transactionRepoObj.getBalance(accountNo);
    }
}
