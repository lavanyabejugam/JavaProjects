package BusinessLayer;

import DomainLayer.Models.*;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IUserRepo;

class UserBusiness implements IUserBusiness {

    IUserRepo _userObj;

    public UserBusiness() {
        _userObj = FactoryRepo.userDetails();
    }
    
    /**
     * Method to set the user details
     * @param robj 
     */
    @Override
    public void setUserDetails(RegistrationModel robj) {

        _userObj.setUserDetails(robj);
    }
    
    /**
     * Method to set the customer details
     * @param cobj 
     */
    @Override
    public void setCustomerDetails(CustomerModel cobj)
    {
        _userObj.setCustomerDetails(cobj);
    }
    
    /**
     * Method to set clerk details
     * @param cobj 
     */
    @Override
    public void setClerkDetails(ClerkModel cobj)
    {
        _userObj.setClerkDetails(cobj);
    }
}
