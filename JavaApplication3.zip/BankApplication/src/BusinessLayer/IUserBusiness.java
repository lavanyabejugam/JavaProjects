package BusinessLayer;

import DomainLayer.Models.*;

public interface IUserBusiness {
    
    /**
     * Method signature to set user details
     * @param robj
     */
    void setUserDetails(RegistrationModel robj);
    
    /**
     * Method signature to set customer details
     * @param robj 
     */
    void setCustomerDetails(CustomerModel robj);
    
    /**
     * Method signature to set clerk details
     * @param robj 
     */
    void setClerkDetails(ClerkModel robj);

}
