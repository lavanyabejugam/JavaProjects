package BusinessLayer;

import DomainLayer.Models.LoginModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IAuthenticateRepo;

class AuthenticationBusiness implements IAuthenticationBusiness {

    IAuthenticateRepo _authObj;
    
    public AuthenticationBusiness()
    {
        _authObj = FactoryRepo.authRepo();
    }
    
    /**
     * Method to validate login
     * @param loginModel
     * @return 
     */
    @Override
    public boolean validateLogin(LoginModel loginModel) {
        
        return _authObj.validateLogin(loginModel);
    }
    
    /**
     * Method to check whether manager has login
     * @param loginModel
     * @return 
     */
    @Override
    public boolean isManager(LoginModel loginModel) {
        
        return _authObj.isManager(loginModel);
    }
    
    /**
     * Method to check whether clerk has login
     * @param loginModel
     * @return 
     */
    @Override
    public boolean isClerk(LoginModel loginModel) {
        
        return _authObj.isClerk(loginModel);
    }
    
    /**
     * Method to check whether customer has login
     * @param loginModel
     * @return 
     */
    @Override
    public boolean isCustomer(LoginModel loginModel) {
        
        return _authObj.isCustomer(loginModel);
    }
    
    /**
     * Method to validate given mail-ID
     * @param email
     * @return 
     */
    @Override
    public boolean validateEmail(String email)
    {
        return _authObj.validateEmail(email);
    }
}
