package RepositoryLayer;

import DomainLayer.Models.*;

public interface IUserRepo {
    
    /**
     * Method signature to set user details
     * @param rmObj 
     */
    void setUserDetails(RegistrationModel rmObj);
    
    /**
     * Method signature to set customer details
     * @param robj 
     */
    void setClerkDetails(ClerkModel robj);
    
    /**
     * Method signature to set customer details
     * @param robj 
     */
    void setCustomerDetails(CustomerModel robj);
}
