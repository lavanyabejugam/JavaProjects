package RepositoryLayer;

import DomainLayer.Models.*;

class UserRepo implements IUserRepo {
    
    /**
     * Method to set the user details
     * @param rmObj 
     */
    @Override
    public void setUserDetails(RegistrationModel rmObj) {
        DataSource._userList.add(rmObj);
    }
    
    /**
     * Method to set the customer details
     * @param cObj 
     */
    @Override
    public void setCustomerDetails(CustomerModel cObj) {
        DataSource._customerList.add(cObj);
    }
    
    /**
     * Method to set clerk details
     * @param cObj 
     */
    @Override
    public void setClerkDetails(ClerkModel cObj) {
        DataSource._clerkList.add(cObj);
    }
}
