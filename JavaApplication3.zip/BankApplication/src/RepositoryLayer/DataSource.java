package RepositoryLayer;

import DomainLayer.Models.*;
import java.util.*;

class DataSource {

    public static List<RegistrationModel> _userList = new ArrayList<>();
    public static List<CustomerModel> _customerList = new ArrayList<>();
    public static List<ClerkModel> _clerkList = new ArrayList<>();

    
    public static List<RegistrationModel> getUserList() {
        return _userList;
    }

    public static void setUserList(List<RegistrationModel> _userList) {
        DataSource._userList = _userList;
    }

    public static List<CustomerModel> getCustomerList() {
        return _customerList;
    }

    public static void setCustomerList(List<CustomerModel> _customerList) {
        DataSource._customerList = _customerList;
    }

    public static List<ClerkModel> getClerkList() {
        return _clerkList;
    }

    public static void setClerkList(List<ClerkModel> _clerkList) {
        DataSource._clerkList = _clerkList;
    }
    
    
}
