package RepositoryLayer;

import java.util.List;

public interface ITransactionRepo {
    
    /**
     * Method signature to deposit given amount into given customer account
     * @param accountNo
     * @param amount 
     */
    void deposit(String accountNo, int amount);
    
    /**
     * Method signature to withdraw given amount from given customer account
     * @param accountNo
     * @param amount 
     */
    void withdraw(String accountNo, int amount);
    
    /**
     * Method signature to return all previous transactions of given customer
     * @param accountNo
     * @return 
     */
    List<String> getPreviousTransaction(String accountNo);
    
    /**
     * Method signature to return total balance of particular customer
     * @param accountNo
     * @return 
     */
    int getBalance(String accountNo);
}
