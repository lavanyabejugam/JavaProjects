package DomainLayer;

public class StringLiterals {

    public final static String VALIDPASSWORD = "Your Password must contain atleast one captial letter, atleastone small letter and atleast one number";
    public final static String INVALIDLOGINPASSWORD = "Password does not match ";
    public final static String INVALIDEMAIL = "Invalid Email";
    public final static String USERCHOICE = "User Choice :";
    public final static String ENTEREMAIL = "Enter Email:";
    public final static String LOGIN = "Enter 1 to Login";
    public final static String REGISTER = "Enter 2 to Register";
    public final static String EXIT = "Enter 3 to Exit";
    public final static String PASSWORD = "Password :";
    public final static String FIRSTNAME = "FirstName :";
    public final static String LASTNAME = "LastName :";
    public final static String TYPEOFREG = "Type of registration";
    public final static String MANAGERCHOICE = "Manager Choice :";
    public final static String ADDCLERK = "Enter 1 to AddClerk";
    public final static String ADDCUSTOMER = "Enter 2 to AddCustomer";
    public final static String VIEWTRANSACTION = "enter 1 to view transactions";
    public final static String DEPOSIT = "enter 2 to deposit";
    public final static String WITHDRAW = "enter 3 to withdraw";
    public final static String CHECKBALANCE = "enter 4 to Check balance";
    public final static String CUSTOMEREXIT = "enter 5 to exit";
    public final static String ACCOUNTNO = "AccountNo :";
    public final static String CLERKFIRSTNAME = "Enter clerk FirstName :";
    public final static String CLERKLASTNAME = "Enter clerk LastName :";
    public final static String CLERKEMAIL = "Enter clerk emailId :";
    public final static String CLERKPASSWORD = "Enter default password for clerk :";
    public final static String CUSTOMERFIRSTNAME = "Enter customer FirstName :";
    public final static String CUSTOMERLASTNAME = "Enter customer LastName :";
    public final static String CUSTOMEREMAIL = "Enter customer emailId :";
    public final static String CUSTOMERPASSWORD = "Enter default password for customer :";
    public final static String CUSTOMERACCNO = "Enter customer account number :";
    public final static String AMOUNTDEPOSIT = "Enter amount to deposit :";
    public final static String AMOUNTWITHDRAW = "Enter amount to withdraw :";
    public final static String BALANCE = "Avaliable balance :";
    public static String LISTOFTRANSACTION = "Luist Of previous transactions :";
    public final static String DEPOSITED = "Deposited :";
    public final static String WITHDRAWN = "WithDraw :";
    public final static String INVALIDCHOICE = "Successfully exited";
}
