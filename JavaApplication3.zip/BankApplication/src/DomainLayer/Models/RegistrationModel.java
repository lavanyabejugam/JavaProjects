package DomainLayer.Models;

public class RegistrationModel {

    private String email;
    private String password;
    private String firstName;
    private String lastName;
    private boolean isManager;

    /**
     * @return the Email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the Email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the Password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the Password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the FirstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the LastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the LastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the IsManager
     */
    public boolean isIsManager() {
        return isManager;
    }

    /**
     * @param IsManager the IsManager to set
     */
    public void setIsManager(boolean IsManager) {
        this.isManager = IsManager;
    }
}
