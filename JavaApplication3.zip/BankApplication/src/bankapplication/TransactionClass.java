package bankapplication;

import BusinessLayer.FactoryBusiness;
import BusinessLayer.ITransactionBusiness;
import DomainLayer.StringLiterals;
import java.util.List;
import java.util.Scanner;

public class TransactionClass {

    ITransactionBusiness _transactionBusiness;
    FactoryBusiness _factoryBusinessObj;

    public TransactionClass() {
        _factoryBusinessObj = new FactoryBusiness();
        _transactionBusiness = _factoryBusinessObj.transactions();
    }
    
    /**
     * Method to perform all type of transactions
     */
    public void transactions() {
        DomainLayer.Enum.Transaction choice;
        String accountNo;
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.println(StringLiterals.VIEWTRANSACTION);
            System.out.println(StringLiterals.DEPOSIT);
            System.out.println(StringLiterals.WITHDRAW);
            System.out.println(StringLiterals.CHECKBALANCE);
            System.out.println(StringLiterals.CUSTOMEREXIT);
            choice = DomainLayer.Enum.Transaction.valueOf(scanner.nextInt());
            scanner.nextLine();
            switch (choice) {
                case VIEWTRANSACTION:
                    System.out.print(StringLiterals.ACCOUNTNO);
                    accountNo = scanner.nextLine();
                    List<String> prevTransaction = _transactionBusiness.getPreviousTransaction(accountNo);
                    System.out.println(StringLiterals.LISTOFTRANSACTION);
                    prevTransaction.stream().forEach(System.out::println);
                    break;
                case DEPOSIT:
                    System.out.print(StringLiterals.AMOUNTDEPOSIT);
                    int amount = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print(StringLiterals.ACCOUNTNO);
                    accountNo = scanner.nextLine();
                    _transactionBusiness.deposit(accountNo, amount);
                    break;
                case WITHDRAW:
                    System.out.print(StringLiterals.AMOUNTWITHDRAW);
                    int withdraw = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print(StringLiterals.ACCOUNTNO);
                    accountNo = scanner.nextLine();
                    _transactionBusiness.withdraw(accountNo, withdraw);
                    break;
                case CHECKBALANCE:
                    System.out.print(StringLiterals.ACCOUNTNO);
                    accountNo = scanner.nextLine();
                    System.out.print(StringLiterals.BALANCE);
                    System.out.println(_transactionBusiness.getBalance(accountNo));
                    break;
                default:
                    System.out.println(StringLiterals.INVALIDCHOICE);
                    break;
            }
        } while (choice != DomainLayer.Enum.Transaction.EXIT);
    }
}
