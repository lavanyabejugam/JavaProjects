package bankapplication;

import BusinessLayer.FactoryBusiness;
import BusinessLayer.IUserBusiness;
import DomainLayer.Enum.ManagerChoice;
import DomainLayer.Models.ClerkModel;
import DomainLayer.Models.CustomerModel;
import DomainLayer.StringLiterals;
import java.util.Scanner;

public class ManagerOperationClass {

    FactoryBusiness _factoryBusinessObj;
    ClerkModel clerkModel;
    IUserBusiness _userObj;
    CustomerModel customerModel;

    public ManagerOperationClass() {
        clerkModel = new ClerkModel();
        customerModel = new CustomerModel();
        _factoryBusinessObj = new FactoryBusiness();
    }
    
    /**
     * Method to performing manager operations
     */
    public void managerOperation() {
        ManagerChoice choice;
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.println(StringLiterals.MANAGERCHOICE);
            System.out.println(StringLiterals.ADDCLERK);
            System.out.println(StringLiterals.ADDCUSTOMER);
            System.out.println(StringLiterals.EXIT);
            choice = ManagerChoice.valueOf(scanner.nextInt());
            scanner.nextLine();
            switch (choice) {
                case ADDCLERK:
                    System.out.print(StringLiterals.CLERKFIRSTNAME);
                    clerkModel.setFirstName(scanner.nextLine());
                    System.out.print(StringLiterals.CLERKLASTNAME);
                    clerkModel.setLastName(scanner.nextLine());
                    System.out.print(StringLiterals.CLERKEMAIL);
                    clerkModel.setEmail(scanner.nextLine());
                    System.out.print(StringLiterals.CLERKPASSWORD);
                    clerkModel.setPassword(scanner.nextLine());
                    clerkModel.setIsClerk(true);
                    _userObj = _factoryBusinessObj.user();
                    _userObj.setClerkDetails(clerkModel);
                    break;
                case ADDCUSTOMER:
                    System.out.print(StringLiterals.CUSTOMERFIRSTNAME);
                    customerModel.setFirstName(scanner.nextLine());
                    System.out.print(StringLiterals.CUSTOMERLASTNAME);
                    customerModel.setLastName(scanner.nextLine());
                    System.out.print(StringLiterals.CUSTOMEREMAIL);
                    customerModel.setEmail(scanner.nextLine());
                    System.out.print(StringLiterals.CUSTOMERPASSWORD);
                    customerModel.setPassword(scanner.nextLine());
                    System.out.print(StringLiterals.CUSTOMERACCNO);
                    customerModel.setAccountNumber(scanner.nextLine());
                    customerModel.setIsCustomer(true);
                    _userObj = _factoryBusinessObj.user();
                    _userObj.setCustomerDetails(customerModel);
                    break;
            }
        } while (choice != ManagerChoice.EXIT);
    }
}
