/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashsetimplementation;

import java.util.*;

/**
 *
 * @author lavanya.bejugam
 */
public class HashSet<E> {
    Map o = new HashMap();
}
