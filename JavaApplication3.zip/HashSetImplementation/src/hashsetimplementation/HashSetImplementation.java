package hashsetimplementation;

import HashMapImplementation.HashMap;

public class HashSetImplementation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HashMap<Integer, StudentInfo> hashMap = new HashMap<>();
        StudentInfo studentInfo = new StudentInfo();   
        studentInfo.setId(1);   
        hashMap.put(studentInfo.getId(),new StudentInfo("Lavanya", "ECE"));
        studentInfo.setId(2);
        hashMap.put(studentInfo.getId(),new StudentInfo("Roja", "CSE"));
        

        System.out.println("value corresponding to key 21="+ hashMap.get(1));
        System.out.println("value corresponding to key 51="+ hashMap.get(2));

        System.out.print("Displaying : ");
        hashMap.display();

//        System.out.println("\n\nvalue corresponding to key 21 removed: "
//                + hashMap.remove(1));
//        System.out.println("value corresponding to key 51 removed: "
//                + hashMap.remove(2));
//
//        System.out.print("Displaying : ");
//        hashMap.display();

    }

}
