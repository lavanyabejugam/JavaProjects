/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package checkfordigit;

/**
 *
 * @author lavanya.bejugam
 */
public class CheckForDigit {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StringOperation stringOperation = new StringOperation();
        stringOperation.setStr("Helloworld9");
        for(char ch : stringOperation.getStr().toCharArray()){
            if(Character.isDigit(ch))
            {
                System.out.println("Yes");
            }
        }
        
    }
    
}
