package arraylistimplementation;

import java.util.Arrays;

public class ArrayList<E> {

    private transient Object[] studentData = new Object[10];
    private static final int MAX_ARRAY_SIZE = Integer.MAX_VALUE - 8;
    private int size;
    
    public int size() {
        return size;
    }
    public E get(int index) {
        return (E) studentData[index];
    }
    public boolean add(E e) {
        increaseCapacity(size + 1);
        studentData[size++] = e;
        return true;
    }

    public void increaseCapacity(int minCapacity) {
        int newCapacity = minCapacity;
        if (newCapacity - MAX_ARRAY_SIZE > 0) {
            newCapacity = hugeCapacity(minCapacity);
        }
        studentData = Arrays.copyOf(studentData, newCapacity);
        
    }

    private static int hugeCapacity(int minCapacity) {
        return (minCapacity > MAX_ARRAY_SIZE) ? Integer.MAX_VALUE : MAX_ARRAY_SIZE;
    }
    
    public void remove(int index) {
        if(index < size)
        {
            int numMoved = size - index - 1;
            if (numMoved > 0) {
                System.arraycopy(studentData, index + 1, studentData, index,
                        numMoved);
            }
            studentData[--size] = null;
        }
    }
    public void printArrayListValues(ArrayList<StudentInfo> list)
    {
        for (int i = 0; i < list.size(); i++) 
        {           
            StudentInfo data = list.get(i); 
            System.out.println(data.getId() + " " + data.getName () + " "+data.getDepartment()); 
        } 
    }
}
