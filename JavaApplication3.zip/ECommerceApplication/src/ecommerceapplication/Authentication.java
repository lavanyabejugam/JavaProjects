package ecommerceapplication;

import BusinessLayer.*;
import DomainLayer.Models.*;
import DomainLayer.StringLiterals;

import java.util.Scanner;

public class Authentication {

    LoginModel _loginmodelObj;
    FactoryBusiness _factoryBusinessObj;
    IAuthenticationBusiness _authObj;
    IUserBusiness _userObj;
    ProductModel _productModelObj;
    AdminOperations _adminOperations;
    CustomerOperations _customerOperations;
    IProductBusiness _productBusiness;

    public Authentication() {

        _loginmodelObj = new LoginModel();
        _factoryBusinessObj = new FactoryBusiness();
        _productModelObj = new ProductModel();
        _adminOperations = new AdminOperations();
        _customerOperations = new CustomerOperations();

    }
    
    /**
     * Method to login to operate on corresponding responsibilities
     */
    public void login() {       
        System.out.print(StringLiterals.EMAIL);
        Scanner scanner = new Scanner(System.in);
        _loginmodelObj.setEmail(scanner.nextLine());
        System.out.print(StringLiterals.PASSWORD);
        _loginmodelObj.setPassword(scanner.nextLine());
        _authObj = _factoryBusinessObj.authenticate();
        if (_authObj.validateLogin(_loginmodelObj)) {

            if (_authObj.isAdmin(_loginmodelObj)) {
                _adminOperations.showOperations();

            } else {
                _customerOperations.showOperations();
                
            }
        } else {
            System.out.println(StringLiterals.INVALIDEMAIL + "or" + StringLiterals.INVALIDLOGINPASSWORD);
        }
    }
    
    /**
     * Method to get details and to register
     */
    public void register() {
        RegistrationModel _registermodelObj = new RegistrationModel();
        Scanner scanner = new Scanner(System.in);
        System.out.print(StringLiterals.FIRSTNAME);
        _registermodelObj.setFirstName(scanner.nextLine());

        System.out.print(StringLiterals.LASTNAME);
        _registermodelObj.setLastName(scanner.nextLine());

        System.out.print(StringLiterals.EMAIL);
        _registermodelObj.setEmail(scanner.nextLine());

        System.out.println(StringLiterals.VALIDPASSWORD);
        System.out.print(StringLiterals.PASSWORD);
        _registermodelObj.setPassword(scanner.nextLine());

        System.out.println(StringLiterals.TYPEOFREG);
        System.out.println(StringLiterals.USERROLECHOICEONE);
        System.out.println(StringLiterals.USERROLECHOICETWO);
        int typeOfReg = Integer.parseInt(scanner.nextLine());
        _registermodelObj.setIsAdmin(typeOfReg == 1);
        if (Validations.validate(_registermodelObj)) {
            _userObj = _factoryBusinessObj.user();
            _userObj.setUserDetails(_registermodelObj);
        }
    }
}
