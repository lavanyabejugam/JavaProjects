package DomainLayer.Models;

import java.util.ArrayList;
import java.util.List;

public class SubCategory {
    
    private String productSubCategory;
    private static final List<SubSubCategory> sububCategory = new ArrayList<>();

    /**
     * @return the productSubCategory
     */
    public String getProductSubCategory() {
        return productSubCategory;
    }

    /**
     * @param productSubCategory the productSubCategory to set
     */
    public void setProductSubCategory(String productSubCategory) {
        this.productSubCategory = productSubCategory;
    }
    
    /**
     * @return the _subsubCategory
     */
    public List<SubSubCategory> getSubsubCategory() {
        return sububCategory;
    }

    /**
     * @param aSubsubCategory the _subsubCategory to set
     */
    public void setSubsubCategory(List<SubSubCategory> aSubsubCategory) {
        this.sububCategory.add((SubSubCategory) aSubsubCategory);
    }
}
