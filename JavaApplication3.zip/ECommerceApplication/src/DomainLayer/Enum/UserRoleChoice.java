package DomainLayer.Enum;

public enum UserRoleChoice { 
    ADMIN, 
    OTHER
}  

