package RepositoryLayer;

import DomainLayer.Models.RegistrationModel;

class UserRepo implements IUserRepo {

    /**
     * Method to set the user details
     * @param rmObj 
     */
    @Override
    public void setUserDetails(RegistrationModel rmObj) {
        DataSource.getUserList().add(rmObj);
    }
}
