package RepositoryLayer;

import DomainLayer.Models.RegistrationModel;

public interface IUserRepo {
    
    /**
     * Method signature to set user details
     * @param rmObj 
     */
    void setUserDetails(RegistrationModel rmObj);
}
