package RepositoryLayer;

import DomainLayer.Models.Category;
import DomainLayer.Models.ProductModel;
import DomainLayer.Models.RegistrationModel;
import java.util.*;

public class DataSource {

    private static List<RegistrationModel> _userList = new ArrayList<>();
    private static List<Category> _categoryList = new ArrayList<>();
    private static List<ProductModel> _cartList = new ArrayList<>();

    /**
     * @return the _userList
     */
    public static List<RegistrationModel> getUserList() {
        return _userList;
    }

    /**
     * @param aUserList the _userList to set
     */
    public static void setUserList(List<RegistrationModel> aUserList) {
        _userList = aUserList;
    }

    /**
     * @return the _categoryList
     */
    public static List<Category> getCategoryList() {
        return _categoryList;
    }

    /**
     * @param aCategoryList the _categoryList to set
     */
    public static void setCategoryList(List<Category> aCategoryList) {
        _categoryList = aCategoryList;
    }

    /**
     * @return the _cartList
     */
    public static List<ProductModel> getCartList() {
        return _cartList;
    }

    /**
     * @param aCartList the _cartList to set
     */
    public static void setCartList(List<ProductModel> aCartList) {
        _cartList = aCartList;
    }
}