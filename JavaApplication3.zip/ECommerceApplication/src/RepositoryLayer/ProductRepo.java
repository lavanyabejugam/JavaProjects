package RepositoryLayer;

import DomainLayer.Models.*;

public class ProductRepo implements IProductRepo {

    /**
     * Method to display all products in the list
     */
    @Override
    public void display() {
        SubSubCategory subSubCategoryObj = new SubSubCategory();
        subSubCategoryObj.getProductModel().stream().map((p) -> {
            System.out.println("ProductName :" + p.getProductName());
            return p;
        }).map((p) -> {
            System.out.println("ProductPrice :" + p.getPrice());
            return p;
        }).map((p) -> {
            System.out.println("ProductDescription :" + p.getDescription());
            return p;
        }).forEach((p) -> {
            System.out.println("AvailableStock :" + p.getAvaliableStock());
        });
        
    }

    /**
     * Method to set product details at particular position
     * @param category
     * @param subCategory
     * @param subSubCategory
     * @param pObj 
     */
    @Override
    public void setProductDetails(String category, String subCategory, String subSubCategory, ProductModel pObj) {
        DataSource.getCategoryList().stream().filter((c) -> (c.getProductCategory().equalsIgnoreCase(category))).forEach((c) -> {
            c.getSubCategory().stream().filter((s) -> (s.getProductSubCategory().equalsIgnoreCase(subCategory))).forEach((s) -> {
                s.getSubsubCategory().stream().filter((ss) -> (ss.getProductSubSubCategory().equalsIgnoreCase(subSubCategory))).forEach((ss) -> {
                    ss.getProductModel().add(pObj);
                });
            });
        });
        
    }
    
    /**
     * Method to add category to category list
     * @param category 
     */
    @Override
    public void setCategory(String category) {
        Category mc1 = new Category();
        mc1.setProductCategory(category);
        DataSource.getCategoryList().add(mc1);
    }
    
    /**
     * Method to add sub-category to given category
     * @param category
     * @param subCategory 
     */
    @Override
    public void setSubCategory(String category, String subCategory) {
        DataSource.getCategoryList().stream().filter((c) -> (c.getProductCategory().equalsIgnoreCase(category))).forEach((c) -> {
            SubCategory sc1 = new SubCategory();
            sc1.setProductSubCategory(subCategory);
            c.getSubCategory().add(sc1);
        });
    }
    
    /**
     * Method to add sub-sub-category to the given sub-category and category
     * @param category
     * @param subCategory
     * @param subSubCategory 
     */
    @Override
    public void setSubSubCategory(String category, String subCategory, String subSubCategory) {
        DataSource.getCategoryList().stream().filter((c) -> (c.getProductCategory().equalsIgnoreCase(category))).forEach((c) -> {
            c.getSubCategory().stream().filter((s) -> (s.getProductSubCategory().equalsIgnoreCase(subCategory))).forEach((s) -> {
                SubSubCategory sc1 = new SubSubCategory();
                sc1.setProductSubSubCategory(subSubCategory);
                s.getSubsubCategory().add(sc1);
            });
        });
    }

    /**
     * Method to remove item from the list
     * @param ItemToBeRemoved 
     */
    @Override
    public void deleteItems(String ItemToBeRemoved) {
        SubSubCategory subSubCategoryObj = new SubSubCategory();
        subSubCategoryObj.getProductModel().stream().forEach((b) -> {
            if ((b.getProductName()).equals(ItemToBeRemoved) && (b.getAvaliableStock() == 1)) {
                subSubCategoryObj.getProductModel().remove(b);
            } else if ((b.getProductName()).equals(ItemToBeRemoved) && (b.getAvaliableStock() > 1)) {
                b.setAvaliableStock(b.getAvaliableStock() - 1);
            }
        });

    }
    
    /**
     * Method to update price of particular product
     * @param productName
     * @param price 
     */
    @Override
    public void updateItem(String productName, float price) {
        SubSubCategory subSubCategoryObj = new SubSubCategory();
        subSubCategoryObj.getProductModel().stream().filter((b) -> (b.getProductName().equals(productName))).forEach((b) -> {
            b.setPrice(price);
        });
    }
    
    /**
     * Method to move particular product into cart-list
     * @param productName 
     */
    @Override
    public void moveItemToCart(String productName) {
        SubSubCategory subSubCategoryObj = new SubSubCategory();
        subSubCategoryObj.getProductModel().stream().filter((b) -> (b.getProductName().equals(productName))).forEach((b) -> {
            DataSource.getCartList().add(b);
        });
    }
    
    /**
     * Method to decrement the available stock value of given particular product when a customer purchase the product
     * @param productName 
     */
    @Override
    public void buyProduct(String productName)
    {
        SubSubCategory subSubCategoryObj = new SubSubCategory();
        subSubCategoryObj.getProductModel().stream().forEach((b) -> {
            if ((b.getProductName()).equals(productName) && (b.getAvaliableStock() > 1)) {
                b.setAvaliableStock(b.getAvaliableStock() - 1);
            }
        });
    }
}
