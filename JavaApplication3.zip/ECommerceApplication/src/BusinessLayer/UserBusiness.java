package BusinessLayer;

import DomainLayer.Models.RegistrationModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IUserRepo;

class UserBusiness implements IUserBusiness {

    IUserRepo _userObj;

    public UserBusiness() {
        _userObj = FactoryRepo.userDetails();
    }

    /**
     * Method to set the user details
     * @param robj 
     */
    @Override
    public void setUserDetails(RegistrationModel robj) {

        _userObj.setUserDetails(robj);
    }
}
