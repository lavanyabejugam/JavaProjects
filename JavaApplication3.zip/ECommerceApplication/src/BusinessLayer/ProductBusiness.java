package BusinessLayer;

import DomainLayer.Models.ProductModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IProductRepo;

public class ProductBusiness implements IProductBusiness {

    IProductRepo _productObj;

    public ProductBusiness() {
        _productObj = FactoryRepo.product();
    }

    /**
     * Method to set product details at particular position
     * @param category
     * @param subCategory
     * @param subSubCategory
     * @param pobj 
     */
    @Override
    public void setProductDetails(String category, String subCategory, String subSubCategory,ProductModel pobj) {
        _productObj.setProductDetails(category, subCategory, subSubCategory, pobj);
    }

    /**
     * Method to remove item from the list
     * @param ItemToBeRemoved 
     */
    @Override
    public void deleteItems(String ItemToBeRemoved) {

        _productObj.deleteItems(ItemToBeRemoved);
    }

    /**
     * Method to update price of particular product
     * @param productName
     * @param price 
     */
    @Override
    public void updateItem(String productName, float price) {
        _productObj.updateItem(productName, price);
    }

    /**
     * Method to display all products in the list
     */
    @Override
    public void display() {
        _productObj.display();
    }

    @Override
    public void moveItemToCart(String productName) {
        _productObj.moveItemToCart(productName);
    }
    
    /**
     * Method to add category to category list
     * @param category 
     */
    @Override
    public void setCategory(String category)
    {
        _productObj.setCategory(category);
    }
    
    /**
     * Method to add sub-category to given category
     * @param category
     * @param subCategory 
     */
    @Override
    public void setSubCategory(String category, String subCategory)
    {
        _productObj.setSubCategory(category, subCategory);
    }
    
    /**
     * Method to add sub-sub-category to the given sub-category and category
     * @param category
     * @param subCategory
     * @param subSubCategory 
     */
    @Override
    public void setSubSubCategory(String category, String subCategory, String subSubCategory)
    {
        _productObj.setSubSubCategory(category, subCategory, subSubCategory);
    }
    
    @Override
    public void buyProduct(String productName){
        _productObj.buyProduct(productName);
    }
}
