/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringoperation;

/**
 *
 * @author lavanya.bejugam
 */
public class StringOperation {

    private String strVar;
    private StringBuffer strBufferVar = new StringBuffer();
    /**
     * @return the strVar
     */
    public String getStrVar() {
        return strVar;
    }

    /**
     * @param strVar the strVar to set
     */
    public void setStrVar(String strVar) {
        this.strVar = strVar;
    }
    
    public String reverseString(String strVar)
    {
        String reverse = " ";
        for(int i = strVar.length() - 1; i >= 0; i--)
        {
            reverse = reverse + strVar.charAt(i);
        }
        return reverse;
    }
    

    /**
     * @return the strBufferVar
     */
    public StringBuffer getStrBufferVar() {
        return strBufferVar;
    }

    /**
     * @param strBufferVar the strBufferVar to set
     */
    public void setStrBufferVar(StringBuffer strBufferVar) {
        this.strBufferVar = strBufferVar;
    }
    
    public String reverseString(StringBuffer strVar)
    {
        String reverse = "";
        for(int i = strVar.length() - 1; i >= 0; i--)
        {
            reverse = reverse + strVar.charAt(i);
        }
        return reverse;
    }

    
}
