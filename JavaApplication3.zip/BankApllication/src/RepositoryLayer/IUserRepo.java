package RepositoryLayer;

import DomainLayer.Enum.UserRoleChoice;
import DomainLayer.Models.RegistrationModel;
import java.util.List;

public interface IUserRepo {

    List<RegistrationModel> getUserDetails(UserRoleChoice role);

    void setUserDetails(RegistrationModel rmObj);
}
