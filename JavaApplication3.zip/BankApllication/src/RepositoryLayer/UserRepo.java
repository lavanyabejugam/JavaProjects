package RepositoryLayer;

import DomainLayer.Enum.UserRoleChoice;
import DomainLayer.Models.RegistrationModel;
import java.util.*;
import java.util.stream.Collectors;

class UserRepo implements IUserRepo {

    @Override
    public List<RegistrationModel> getUserDetails(UserRoleChoice role) {
        if (role == UserRoleChoice.Admin) {
            return DataSource._userList.stream().filter(p -> p.isIsAdmin()).collect(Collectors.toList());
        } else {
            return DataSource._userList.stream().collect(Collectors.toList());
        }
    }

    @Override
    public void setUserDetails(RegistrationModel rmObj) {
        DataSource._userList.add(rmObj);
    }
}
