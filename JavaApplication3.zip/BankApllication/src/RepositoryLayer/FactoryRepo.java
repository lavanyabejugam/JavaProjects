package RepositoryLayer;

public class FactoryRepo {

    public static IAuthenticateRepo authRepo() {
        return new AuthenticationRepo();
    }

    public static IUserRepo userDetails() {
        return new UserRepo();
    }

    public static IProductRepo product() {
        return new ProductRepo();
    }
}
