package ecommerceapplication;

import BusinessLayer.FactoryBusiness;
import BusinessLayer.IProductBusiness;

public class CustomerOperations {

    IProductBusiness _productObj;

    FactoryBusiness _factoryBusinessObj;

    public CustomerOperations() {
        _factoryBusinessObj = new FactoryBusiness();
    }

    void moveItemToCart(String productName) {
        _productObj = _factoryBusinessObj.product();
        _productObj.moveItemToCart(productName);
    }

}
