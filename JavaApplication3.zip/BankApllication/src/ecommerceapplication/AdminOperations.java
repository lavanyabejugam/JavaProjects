package ecommerceapplication;

import BusinessLayer.FactoryBusiness;
import BusinessLayer.IProductBusiness;
import DomainLayer.Enum.*;
import DomainLayer.Models.ProductModel;
import DomainLayer.StringLiterals;
import java.util.Scanner;

public class AdminOperations {

    IProductBusiness _productObj;

    FactoryBusiness _factoryBusinessObj;

    public AdminOperations() {

        _factoryBusinessObj = new FactoryBusiness();

    }

    void addItems() { 
        Scanner scanner = new Scanner(System.in);

        System.out.println(StringLiterals._noOfItems);
        int items = scanner.nextInt();
        
        while (items != 0) {
            ProductModel _productModelObj = new ProductModel();
            System.out.println("Enter Category :");
            _productModelObj.category = ProductCategory.valueOf(scanner.nextInt());
            
            System.out.println("Enter Sub-Category :");
            _productModelObj.subCategory = ProductSubCategory.valueOf(scanner.nextInt());

            System.out.println(StringLiterals._productName);
            _productModelObj.productName = scanner.next();
            System.out.println(StringLiterals._enterPrice);
            _productModelObj.price = Float.parseFloat(scanner.next());
            System.out.println(StringLiterals._description);
            _productModelObj.description = scanner.next();
            System.out.println(StringLiterals._availableStock);
            _productModelObj.avaliableStock = scanner.nextInt();
            _productObj = _factoryBusinessObj.product();
            _productObj.setProductDetails(_productModelObj);
            items--;
        }
    }

    void removeItems(String ItemToBeRemoved) {
        _productObj = _factoryBusinessObj.product();
        _productObj.deleteItems(ItemToBeRemoved);
    }

    void updateItem(String productName, float price) {
        _productObj = _factoryBusinessObj.product();
        _productObj.updateItem(productName, price);
    }
}
