package BusinessLayer;

import DomainLayer.Models.RegistrationModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IAuthenticateRepo;

public class Validations {

    public static boolean validate(RegistrationModel registerModel) {
        if (validateEmail(registerModel.Email) && validatePassword(registerModel.Password) && validateFirstName(registerModel.FirstName) && validateLastName(registerModel.LastName)) {
            return true;
        }
        return false;
    }

    public static boolean validateEmail(String email) {
        IAuthenticateRepo _authObj;
        _authObj = FactoryRepo.authRepo();
        boolean Flag = false;
        if (email.contains("@") && email.contains(".com") && _authObj.validateEmail(email)) {
            Flag = true;
        }
        return Flag;
    }

    public static boolean validatePassword(String password) {
        int validConditions = 0;
        if (password.length() < 5) {
            return false;
        }
        for (char c : password.toCharArray()) {
            if (c >= 'a' && c <= 'z') {
                validConditions++;
                break;
            }
        }
        for (char c : password.toCharArray()) {
            if (c >= 'A' && c <= 'Z') {
                validConditions++;
                break;
            }
        }
        for (char c : password.toCharArray()) {
            if (c >= '0' && c <= '9') {
                validConditions++;
                break;
            }
        }
        if (validConditions == 3) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean validateFirstName(String Name) {
        if (Name.length() > 0) {
            return true;
        }
        return false;
    }

    public static boolean validateLastName(String Name) {
        if (Name.length() > 0) {
            return true;
        }
        return false;
    }

}
