package BusinessLayer;

import DomainLayer.Models.LoginModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IAuthenticateRepo;

class AuthenticationBusiness implements IAuthenticationBusiness {

    IAuthenticateRepo _authObj;

    @Override
    public boolean validateLogin(LoginModel loginModel) {
        _authObj = FactoryRepo.authRepo();
        return _authObj.validateLogin(loginModel);
    }

    @Override
    public boolean isAdmin(LoginModel loginModel) {
        _authObj = FactoryRepo.authRepo();
        return _authObj.isAdmin(loginModel);
    }
}
