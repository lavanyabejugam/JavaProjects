package DomainLayer.Enum;

import java.util.*;

public enum ProductSubCategory {
    Moto(1),
    Redmi(2);
    private int value;
    private static Map map = new HashMap<>();

    private ProductSubCategory(int value) {
        this.value = value;
    }

    static {
        for (ProductSubCategory productSubCategory : ProductSubCategory.values()) {
            map.put(productSubCategory.value, productSubCategory);
        }
    }

    public static ProductSubCategory valueOf(int productSubCategory) {
        return (ProductSubCategory) map.get(productSubCategory);
    }
}
