package DomainLayer.Enum;

import java.util.*;

public enum CustomerOptions {

    MOVETOCART(1),
    BUY(2),
    EXIT(3);
    private int value;
    private static final Map map = new HashMap<>();

    private CustomerOptions(int value) {
        this.value = value;
    }

    static {
        for (CustomerOptions customerOptions : CustomerOptions.values()) {
            map.put(customerOptions.value, customerOptions);
        }
    }

    public static CustomerOptions valueOf(int customerOptions) {
        return (CustomerOptions) map.get(customerOptions);
    }
}
