package ecommerceapplication;

import DomainLayer.Enum.LoginPageChoice;
import DomainLayer.StringLiterals;
import java.util.Scanner;

public class ECommerceApplication {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        Authentication authentication = new Authentication();
        LoginPageChoice choice;
        do {

            System.out.println(StringLiterals.USERCHOICE);
            System.out.println(StringLiterals.LOGIN);
            System.out.println(StringLiterals.REGISTER);
            System.out.println(StringLiterals.EXITOPTION);
            choice = LoginPageChoice.valueOf(scanner.nextInt());
            switch (choice) {
                case LOGIN:
                    authentication.login();
                    break;

                case REGISTER:
                    authentication.register();
                    break;
			default:
				break;
            }
        } while (choice != LoginPageChoice.EXIT);
    }

}
