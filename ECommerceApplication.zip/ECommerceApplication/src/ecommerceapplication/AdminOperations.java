package ecommerceapplication;

import BusinessLayer.FactoryBusiness;
import BusinessLayer.IProductBusiness;
import DomainLayer.Enum.*;
import DomainLayer.Models.ProductModel;
import DomainLayer.StringLiterals;
import java.util.Scanner;

public class AdminOperations {

    FactoryBusiness _factoryBusinessObj;
    IProductBusiness _productBusiness;

    public AdminOperations() {
        _factoryBusinessObj = new FactoryBusiness();

    }
    
    /**
     * Method to show and perform admin operations
     */
    public void showOperations() {

        Scanner scanner = new Scanner(System.in);
        AdminOptions option;
        
        do {
            System.out.println(StringLiterals.ADMINCHOICE);
            System.out.println(StringLiterals.ADDPRODUCT);
            System.out.println(StringLiterals.DELETE);
            System.out.println(StringLiterals.UPDATE);
            System.out.println(StringLiterals.EXIT);

            option = AdminOptions.valueOf(scanner.nextInt());
            scanner.nextLine();
            switch (option) {
                case ADDPRODUCT:               
                    this.addItems();
                    break;
                case DELETEPRODUCT:
                    _productBusiness = _factoryBusinessObj.product();
                    _productBusiness.display();
                    System.out.println(StringLiterals.REMOVE);
                    String ItemToBeRemoved = scanner.nextLine();
                    this.removeItems(ItemToBeRemoved);
                    break;
                case UPDATE:
                    _productBusiness = _factoryBusinessObj.product();
                    _productBusiness.display();
                    System.out.println(StringLiterals.SELECTTOUPDATE);
                    String productName = scanner.nextLine();
                    System.out.println(StringLiterals.PRICE);
                    float price = Float.parseFloat(scanner.nextLine());
                    this.updateItem(productName, price);
                    break;
                default :
                    System.out.println(StringLiterals.INVALIDCHOICE);

            }
        } while (option != AdminOptions.EXIT);
    }
    
    /**
     * Method to add items into corresponding position
     * @param category
     * @param subCategory
     * @param subSubCategory 
     */
    public void addItems() {
        Scanner scanner = new Scanner(System.in);

        System.out.println(StringLiterals.NOOFITEMS);
        int items = scanner.nextInt();

        while (items != 0) {
            ProductModel _productModelObj = new ProductModel();

            System.out.println(StringLiterals.ADDCATEGORY);
            _productModelObj.setProductCategory(scanner.next());
            System.out.println(StringLiterals.ADDSUBCATEGORY);
            _productModelObj.setProductSubCategory(scanner.next());
            System.out.println(StringLiterals.ENTERPRODUCTNAME);
            _productModelObj.setProductName(scanner.next());
            System.out.println(StringLiterals.ENTERPRICE);
            _productModelObj.setPrice(Float.parseFloat(scanner.next()));
            System.out.println(StringLiterals.DESCRIPTION);
            _productModelObj.setDescription(scanner.next());
            System.out.println(StringLiterals.AVAILABLESTOCK);
            _productModelObj.setAvailableStock(scanner.nextInt());
            scanner.nextLine();
            _productBusiness = _factoryBusinessObj.product();
            _productBusiness.setProductDetails(_productModelObj);
            items--;
        }
    }
    
    /**
     * Method to remove particular item from the list
     * @param itemToBeRemoved 
     */
    public void removeItems(String itemToBeRemoved) {
        _productBusiness = _factoryBusinessObj.product();
        _productBusiness.deleteItems(itemToBeRemoved);
    }
    
    /**
     * Method to update price of particular product
     * @param productName
     * @param price 
     */
    public void updateItem(String productName, float price) {
        _productBusiness = _factoryBusinessObj.product();
        _productBusiness.updateItem(productName, price);
    }
}
