package RepositoryLayer;

import DomainLayer.Models.ProductModel;

public interface IProductRepo {

    /**
     * Method signature to set product details at particular position
     * @param category
     * @param subCategory
     * @param subSubCategory
     * @param pObj 
     */
    public void setProductDetails(ProductModel pObj);
    
    /**
     * Method signature to delete product from the product-list
     * @param ItemToBeRemoved 
     */
    public void deleteItems(String ItemToBeRemoved);

    /**
     * Method signature to update price of a particular product
     * @param productName
     * @param price 
     */
    public void updateItem(String productName, float price);

    /**
     * Method signature to display all products in the list
     */
    public void display();
    
    /**
     * Method signature to move particular product into cart-list
     * @param productName 
     */
    public void moveItemToCart(String productName);
    
    /**
     * Method signature to decrement the available stock value of given particular product when a customer purchase the product
     * @param productName 
     */
    public void buyProduct(String productName);
    
}
