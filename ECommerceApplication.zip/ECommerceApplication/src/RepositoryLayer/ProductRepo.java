package RepositoryLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import DomainLayer.Models.*;

public class ProductRepo implements IProductRepo {

	/**
	 * Method to display all products in the list
	 */
	@Override
	public void display() {
		String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection conn = DriverManager.getConnection(JDBC_URL);
			String sqll = "select * from dbo.ProductList";
			PreparedStatement pstmt = conn.prepareStatement(sqll);			
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				System.out.println(rs.getString("ProductName"));
			}
		} catch (Exception sqlException) {
			sqlException.printStackTrace();
		}
	}

	/**
	 * Method to set product details at particular position
	 * 
	 * @param category
	 * @param subCategory
	 * @param subSubCategory
	 * @param pObj
	 */
	@Override
	public void setProductDetails(ProductModel pObj) {
		String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection conn = DriverManager.getConnection(JDBC_URL);
			String sqll = "Insert into dbo.ProductList (Category, SubCategory, ProductName, Price, AvailableStock, Description) Values (?, ?, ?, ?, ?, ?)";
			PreparedStatement pstmt = conn.prepareStatement(sqll);
			pstmt.setString(1, pObj.getProductCategory());
			pstmt.setString(2, pObj.getProductSubCategory());
			pstmt.setString(3, pObj.getProductName());
			pstmt.setDouble(4, pObj.getPrice());
			pstmt.setInt(5, pObj.getAvailableStock());
			pstmt.setString(6, pObj.getDescription());
			int j = pstmt.executeUpdate();
		} catch (Exception sqlException) {
			sqlException.printStackTrace();
		}
	}

	/**
	 * Method to remove item from the list
	 * 
	 * @param ItemToBeRemoved
	 */
	@Override
	public void deleteItems(String ItemToBeRemoved) {
		String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection conn = DriverManager.getConnection(JDBC_URL);
			String sql = "Select AvailableStock from dbo.ProductList where ProductName = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, ItemToBeRemoved);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				if (rs.getInt("AvailableStock") > 1) {
					String sqll = "with cte as ( select AvailableStock from dbo.ProductList) update cte set AvailableStock = AvailableStock -1";
					PreparedStatement pstmt = conn.prepareStatement(sqll);
					int j = pstmt.executeUpdate();
				} else {
					PreparedStatement ps = null;
					String sqll = null;
					sqll = "Delete from dbo.ProductList where ProductName = ?";
					ps = conn.prepareStatement(sqll);
					ps.setString(1, ItemToBeRemoved);
					int j = ps.executeUpdate();
				}
			}

		} catch (Exception sqlException) {
			sqlException.printStackTrace();
		}
	}

	/**
	 * Method to update price of particular product
	 * 
	 * @param productName
	 * @param price
	 */
	@Override
	public void updateItem(String productName, float price) {
		String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection conn = DriverManager.getConnection(JDBC_URL);
			String sql = "Select * from dbo.ProductList where ProductName = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, productName);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				String sqll = "with cte as ( select * from dbo.ProductList where ProductName = ?) update cte set Price = ?";
				PreparedStatement pstmt = conn.prepareStatement(sqll);
				stmt.setString(1, productName);
				pstmt.setFloat(2, price);
				int j = pstmt.executeUpdate();
				
			}

		} catch (Exception sqlException) {
			sqlException.printStackTrace();
		}
	}

	/**
	 * Method to move particular product into cart-list
	 * 
	 * @param productName
	 */
	@Override
	public void moveItemToCart(String productName) {
		String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection conn = DriverManager.getConnection(JDBC_URL);
			String sql = "INSERT INTO CartList (Category, SubCategory, ProductName, Price, AvailableStock, Description)SELECT Category, SubCategory, ProductName, Price, AvailableStock, Description FROM ProductList WHERE ProductName = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, productName);
			int j = stmt.executeUpdate();
		} catch (Exception sqlException) {
			sqlException.printStackTrace();
		}
	}

	/**
	 * Method to decrement the available stock value of given particular product
	 * when a customer purchase the product
	 * 
	 * @param productName
	 */
	@Override
	public void buyProduct(String productName) {
		String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection conn = DriverManager.getConnection(JDBC_URL);
			String sql = "Select AvailableStock from dbo.ProductList where ProductName = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, productName);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				if (rs.getInt("AvailableStock") > 1) {
					String sqll = "with cte as ( select AvailableStock from dbo.ProductList) update cte set AvailableStock = AvailableStock -1";
					PreparedStatement pstmt = conn.prepareStatement(sqll);
					int j = pstmt.executeUpdate();
				} else {
					PreparedStatement ps = null;
					String sqll = null;
					sqll = "Delete from dbo.ProductList where ProductName = ?";
					ps = conn.prepareStatement(sqll);
					ps.setString(1, productName);
					int j = ps.executeUpdate();
				}
			}

		} catch (Exception sqlException) {
			sqlException.printStackTrace();
		}
	}
}
