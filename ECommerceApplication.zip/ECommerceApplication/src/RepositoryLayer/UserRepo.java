package RepositoryLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import DomainLayer.Models.RegistrationModel;

class UserRepo implements IUserRepo {

    /**
     * Method to set the user details
     * @param rmObj 
     */
    @Override
    public void setUserDetails(RegistrationModel rmObj) {
    	String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
    	try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection conn = DriverManager.getConnection(JDBC_URL);
			String sqll = "Insert into dbo.EcommerceApplication (Email, FirstName, LastName, Password, isAdmin) Values (?, ?, ?, ?, ?)";
			PreparedStatement pstmt = conn.prepareStatement(sqll);
			pstmt.setString(1, rmObj.getEmail());
			pstmt.setString(2, rmObj.getFirstName());
			pstmt.setString(3, rmObj.getLastName());
			pstmt.setString(4, rmObj.getPassword());
			pstmt.setBoolean(5, rmObj.isIsAdmin());
			int j=pstmt.executeUpdate();
		} 
    	catch(Exception sqlException) {
			sqlException.printStackTrace();
    	}
    }
}
