package RepositoryLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DataSource {

	static
	{
		final String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
		
    	try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection conn = DriverManager.getConnection(JDBC_URL);
			String sql = "create table dbo.EcommerceApplication(Email varchar(255), FirstName varchar(255), LastName varchar(255), Password varchar(255))";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.executeUpdate();
			String sqll = "Insert into dbo.EcommerceApplication (Email, FirstName, LastName, Password, isAdmin) Values (?, ?, ?, ?, ?)";
			PreparedStatement pstmt = conn.prepareStatement(sqll);
			pstmt.setString(1, "b@.com");
			pstmt.setString(2, "lavanya");
			pstmt.setString(3, "bejugam");
			pstmt.setString(4, "Bl@vanya1");
			pstmt.executeUpdate();
		} 
    	catch(Exception sqlException) {
			sqlException.printStackTrace();
    	}
    	
	}
}