package RepositoryLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import DomainLayer.Models.LoginModel;
import DomainLayer.Models.RegistrationModel;

class AuthenticationRepo implements IAuthenticateRepo {

	/**
	 * Method to validate login
	 * 
	 * @param loginModel
	 * @return
	 */
	@Override
	public boolean validateLogin(LoginModel loginModel) {
		Connection conn;
		final String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(JDBC_URL);
			String pp = loginModel.getEmail();
			String ppp = loginModel.getPassword();
			String sql = "select Password from EcommerceApplication where Email = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, loginModel.getEmail());
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				String p = rs.getString("Password");
				if (p.equals(ppp)) {
					return true;
				}
			}
		} catch (Exception sqlException) {
			sqlException.printStackTrace();
		}
		return false;
	}

	/**
	 * Method to validate given mail-ID
	 * 
	 * @param email
	 * @return
	 */
	@Override
	public boolean validateEmail(String email) {
		// DataSource obj = new DataSource();
		Connection conn;
		final String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(JDBC_URL);
			String sql = "select * from EcommerceApplication where Email = ?";
			PreparedStatement stmt = conn. prepareStatement(sql);
			stmt.setString(1, email);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				return false;
			}
		} catch (Exception sqlException) {
			sqlException.printStackTrace();
		}
		return true;
	}

	/**
	 * Method to check whether admin has login
	 * 
	 * @param loginModel
	 * @return
	 */
	@Override
	public boolean isAdmin(LoginModel loginModel) {
		Connection conn;
		final String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=banana;integratedSecurity=true";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(JDBC_URL);
			String sql = "select * from EcommerceApplication where Email = ? and isAdmin = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, loginModel.getEmail());
			stmt.setInt(2, 1);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (Exception sqlException) {
			sqlException.printStackTrace();
		}
		return false;
	}
}
