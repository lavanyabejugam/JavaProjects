package BusinessLayer;

import DomainLayer.Models.LoginModel;

public interface IAuthenticationBusiness {

    /**
     * Method signature to validate login
     * @param loginModel
     * @return 
     */
    boolean validateLogin(LoginModel loginModel);

    /**
     * Method signature to validate email
     * @param email
     * @return 
     */
    boolean validateEmail(String email);

    /**
     * Method signature to check whether admin has login
     * @param loginModel
     * @return 
     */
    boolean isAdmin(LoginModel loginModel);
}
