package BusinessLayer;

import DomainLayer.Models.LoginModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IAuthenticateRepo;

class AuthenticationBusiness implements IAuthenticationBusiness {

    IAuthenticateRepo _authObj;

    public AuthenticationBusiness()
    {
        _authObj = FactoryRepo.authRepo();
    }
    /**
     * Method to validate login
     * @param loginModel
     * @return 
     */
    @Override
    public boolean validateLogin(LoginModel loginModel) {
        
        return _authObj.validateLogin(loginModel);
    }

    /**
     * Method to validate given mail-ID
     * @param email
     * @return 
     */
    @Override
    public boolean validateEmail(String email) {
        return _authObj.validateEmail(email);
    }
    
    /**
     * Method to check whether admin has login
     * @param loginModel
     * @return 
     */
    @Override
    public boolean isAdmin(LoginModel loginModel) {
        return _authObj.isAdmin(loginModel);
    }
}
