package BusinessLayer;

import DomainLayer.Models.ProductModel;
import RepositoryLayer.FactoryRepo;
import RepositoryLayer.IProductRepo;

public class ProductBusiness implements IProductBusiness {

    IProductRepo _productObj;

    public ProductBusiness() {
        _productObj = FactoryRepo.product();
    }

    /**
     * Method to set product details at particular position
     * @param category
     * @param subCategory
     * @param subSubCategory
     * @param pobj 
     */
    @Override
    public void setProductDetails(ProductModel pobj) {
        _productObj.setProductDetails(pobj);
    }

    /**
     * Method to remove item from the list
     * @param ItemToBeRemoved 
     */
    @Override
    public void deleteItems(String ItemToBeRemoved) {

        _productObj.deleteItems(ItemToBeRemoved);
    }

    /**
     * Method to update price of particular product
     * @param productName
     * @param price 
     */
    @Override
    public void updateItem(String productName, float price) {
        _productObj.updateItem(productName, price);
    }

    /**
     * Method to display all products in the list
     */
    @Override
    public void display() {
        _productObj.display();
    }

    @Override
    public void moveItemToCart(String productName) {
        _productObj.moveItemToCart(productName);
    }
    
    @Override
    public void buyProduct(String productName){
        _productObj.buyProduct(productName);
    }
}
