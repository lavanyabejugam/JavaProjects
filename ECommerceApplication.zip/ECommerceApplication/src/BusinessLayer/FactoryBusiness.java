package BusinessLayer;

public class FactoryBusiness {

    public IAuthenticationBusiness authenticate() {
        return new AuthenticationBusiness();
    }

    public IUserBusiness user() {
        return new UserBusiness();
    }

    public IProductBusiness product() {
        return new ProductBusiness();
    }
}
