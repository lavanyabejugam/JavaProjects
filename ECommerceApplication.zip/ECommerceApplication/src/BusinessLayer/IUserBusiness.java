package BusinessLayer;

import DomainLayer.Models.RegistrationModel;

public interface IUserBusiness {

    /**
     * Method signature to set user details
     * @param robj
     */
    void setUserDetails(RegistrationModel robj);

}
